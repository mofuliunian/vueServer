<template>
  <div class="index">
    <div class="index-swiper" :class="{'show-swiper': isShowSwiper}">
      <swiper :options="swiperOption" ref="mySwiper" class="index-swiper-wrapper">
        <!-- 这部分放你要渲染的那些内容 -->
        <swiper-slide v-for="(item, index) in items" :key="items.id" class="slide-content">
          <img :src="'/heo/dist/static/images/banner_'+item.id+'_02.jpg'" alt="">
          <div class="index-swiper-tips">{{item.desc}}</div>
        </swiper-slide>
        <!-- 这是轮播的小圆点 -->
        <div class="swiper-pagination" slot="pagination">
        </div>
      </swiper>
      <div class="index-swiper-btn" @click="onUpData">
        <au-button :btnType="btnType" text="马上加入"></au-button>
      </div>
      <i class="icon-cancel" @click="onCancel"></i>
      <div class="index-swiper-bg" v-if="!isShowSwiper"></div>
    </div>

    <div class="index-content">
      <div class="index-banner">
        <img src="../../assets/images/index-banner.jpg" alt="">
      </div>
      <div class="index-swiper-banner-content">
        <div class="index-swiper-banner">
          <ul class="flex banner-list">
            <li v-for="(item, index) in items" @click="setSlideTo(index)">
              <img :src="'/heo/dist/static/images/swiper_'+item.id+'.jpg'" alt="">
              <span>{{item.title}}</span>
            </li>
          </ul>
          <div class="index-btn" @click="onUpData">
            <au-button :btnType="btnType" text="马上加入"></au-button>
          </div>
        </div>
      </div>

      <div class="index-activity">
        <h3>爱车精神</h3>
        <img src="../../../static/images/banner_1.jpg" class="index-activity-banner" alt="">
        <p>超跑基地让大家加速度炫酷</p>
      </div>

      <div class="index-activity">
        <img src="../../../static/images/banner_2.jpg" class="index-activity-banner" alt="">
        <p>世界小姐上海赛区完美落幕 </p>
      </div>

      <div class="index-activity" >
        <h3>会员showing</h3>

        <au-usershowing v-for="(item, index) in user" :key="index" :userContent="item" class="user-content"></au-usershowing>
      </div>

    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters } from 'vuex';
  import { swiper, swiperSlide } from 'vue-awesome-swiper';
  import auUsershowing from 'base/userimg/userShowing';

  export default {
    name: '',
    data() {
      return {
        page: 0,
        index: 0,
        isShowSwiper: false,
        user: [
          {
            name: '任锋',
            text: '上海疆智贸易有限公司\n执行董事兼总经理',
            img: '/heo/dist/static/images/hy_rf.jpg',
          },
          {
            name: '刁丽娜',
            text: '澳洲金鼎集团\n市场部负责人',
            img: '/heo/dist/static/images/hy_dln.jpg',
          },
          {
            name: '顾益明',
            text: '上海泉贡餐饮有限公司 董事长\n顾森品牌牛肉 创始人',
            img: '/heo/dist/static/images/hy_gym.jpg',
          },
        ],
        swiperOption: {
          pagination: {
            el: '.swiper-pagination',
            clickable: true,
          },
          notNextTick: true,
          slidesPerView: 'auto',
          centeredSlides: true,
          paginationClickable: true,
          autoplay: {
            delay: 3000,
            disableOnInteraction: false,
          },
          spaceBetween: 0,
          on: {
            slideChangeTransitionEnd: () => {
              this.page = this.swipers.realIndex + 1;
              this.index = this.swipers.realIndex;
            },
          },
        },
        btnType: 'btn-index',
        items: [
          {
            imgSrc: 'https://si.geilicdn.com/open_1486195304408_98.png',
            id: 1,
            title: '救援计划',
            desc: '免费救援（事故）\\搭电\\送油',
          },
          {
            imgSrc: 'https://si.geilicdn.com/open_1478070715422_302.jpg',
            id: 2,
            title: '爱车保养',
            desc: '官方指定场所保养七折优惠',
          },
          {
            imgSrc: 'https://si.geilicdn.com/open_1486195304408_98.png',
            id: 3,
            title: '会员好礼',
            desc: '365天安全驾驶送会费等值好礼',
          },
          {
            imgSrc: 'https://si.geilicdn.com/open_1478070715422_302.jpg',
            id: 4,
            title: '自驾穿越',
            desc: '携手体验穿越无人区的刺激',
          },
          {
            imgSrc: 'https://si.geilicdn.com/open_1486195304408_98.png',
            id: 5,
            title: '私享酒会',
            desc: '极致的味觉体验，情感的释放',
          },
          {
            imgSrc: 'https://si.geilicdn.com/open_1478070715422_302.jpg',
            id: 6,
            title: '嘉年华',
            desc: '会员嘉年华，玩到想回童年',
          },
          {
            imgSrc: 'https://si.geilicdn.com/open_1478070715422_302.jpg',
            id: 7,
            title: '网红排队',
            desc: '网红直播聚会，新玩法新体验',
          },
          {
            imgSrc: 'https://si.geilicdn.com/open_1478070715422_302.jpg',
            id: 8,
            title: '见面会',
            desc: '知名企业家\\媒体人亲密见面会',
          },
          {
            imgSrc: 'https://si.geilicdn.com/open_1478070715422_302.jpg',
            id: 9,
            title: '超速体验',
            desc: '体验弹射起步，做个追风的人',
          },
        ],
      };
    },
    components: {
      swiper,
      swiperSlide,
      auUsershowing,
    },
    computed: {
      swipers() {
        return this.$refs.mySwiper.swiper;
      },
      ...mapGetters([
        'getUser',
      ]),
    },
    methods: {
      setSlideTo(index) {
        this.isShowSwiper = true;
        this.swipers.slideTo(index, 0, false);
      },
      onCancel() {
        this.isShowSwiper = false;
        this.swipers.slideTo(0, 0, false);
      },
      onUpData() {
        if (this.getUser.isMembership) {
          this.$router.push({ path: '/service/myService' });
        } else {
          this.$router.push({ path: '/member/newLogin' });
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  @import '~assets/styles/variable';
  .index-banner{
    padding-bottom: 42px;
    background-color: $default-body-background;
  }
  .index-content {
    position: relative;
    z-index: 10;
    background-color: $index-color-background;
  }
  .index-swiper{
    position: absolute;
    top: 0;
    left: 0;
    z-index: 9;
    overflow: hidden;
    width: 750px;
    background-color: $default-body-background;

  &.show-swiper{
     z-index: 12;
   }

  .index-swiper-wrapper{
    position: relative;
    height: 1030px;
    background-color: $default-body-background;
  }

  .slide-content {
    position: relative;
    width: 750px;
  }

  .index-swiper-btn {
    width: 666px;
    margin: 0 auto;
    padding-top: 42px;
    padding-bottom: 35px;
    background-color: $default-body-background;
  }

  .swiper-pagination {
    position: absolute;
    left: 0;
    bottom: 20px;
    width: 750px;
    text-align: center;
  }

  .icon-cancel{
    position: absolute;
    top: 40px;
    right: 40px;
    width: 40px;
    height: 40px;
  }
  }

  .index-swiper-banner-content {
    width: 750px;
    margin-bottom: 22px;
    background-color: $default-body-background;

  .index-btn {
    margin-top: 24px;
    padding-bottom: 78px;
  }
  }
  .index-swiper-banner {
    width: 666px;
    margin: 0 auto;
  }
  .banner-list {
    flex-direction: row;
    justify-content: space-between;
    flex-wrap: wrap;
    background-color: $default-body-background;

  li {
    position: relative;
    width: 210px;
    height: 210px;
    margin-bottom: 18px;

  img{
    width: 210px;
    height: 210px;
  }

  span {
    position: absolute;
    top: 0;
    left: 0;
    width: 210px;
    height: 210px;
    line-height: 210px;
    text-align: center;
    font-size: $default-input-placeholder-font-size;
    color: $default-body-background;
  }
  }
  }

  .index-activity {
    margin-top: 10px;
    padding-top: 10px;
    background-color: $default-body-background;

  h3 {
    font-size: 42px;
    padding-top: 50px;
    color: $index-color-text;
    text-align: center;
  }

  .index-activity-banner {
    width: 666px;
    height: 362px;
    margin: 40px auto 0;
  }
  p {
    margin-top: 38px;
    padding-bottom: 76px;
    text-align: center;
    color: $index-color-text;
    font-size: $default-input-placeholder-font-size;
  }
  }

  .user-content {
    margin-top: 22px;
    padding-bottom: 20px;
  }

  .index-swiper-bg {
    position: absolute;
    top:0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: $default-body-background;
    z-index: 8;
  }

  .index-swiper-tips {
    position: absolute;
    left: 0;
    font-size: 33px;
    bottom: 145px;
    width: 100%;
    color: #FFF;
    text-align: center;
  }
</style>        
