<template>
  <div class="login">
    <div class="new-login">
      <img src="../../../assets/images/login_top.png" alt="">
      <div class="form">
        <au-input
                v-model="name.value"
                class="form-input"
                :maxLength="name.length"
                :placeholder="name.placeholder"
                @handleBlur="onName">
          <i class="form-icon icon-name"></i>
        </au-input>
      </div>
      <div class="form">
        <au-input
                v-model="tel.value"
                class="form-input"
                :type="'tel'"
                :maxLength="tel.length"
                :placeholder="tel.placeholder"
                @handleBlur="onTel">
          <i class="form-icon icon-tel"></i>
        </au-input>
      </div>
      <div class="form">
        <au-input
                v-model="code.value"
                class="form-input"
                :maxLength="code.length"
                :placeholder="code.placeholder"
                @handleBlur="onCode">
          <i class="form-icon icon-code"></i>
        </au-input>
        <au-code :codeTel="tel.value" :codeType="1"></au-code>
      </div>
      <div class="login-cont" @click="onUpData">
        <au-button :btnType="btnType" text="提交"></au-button>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapActions } from 'vuex';
  import auCode from 'base/code/code';
  import { checkPhoneE, upSave } from '../../../api/request';

  export default {
    name: '',
    data() {
      return {
        isUpdate: false,
        name: {
          value: '',
          length: 5,
          placeholder: '姓名',
          isValue: false,
        },
        tel: {
          value: '',
          length: 11,
          placeholder: '手机号',
          isValue: false,
        },
        code: {
          value: '',
          length: 6,
          placeholder: '验证码',
          isValue: false,
        },
        btnType: 'btn-disabled',
        codeTel: '',
      };
    },
    components: {
      auCode,
    },
    methods: {
      ...mapActions([
        'setUsrName',
        'setLoginName',
        'setLoginTel',
      ]),
      onName(value) {
        const res = /[\u4e00-\u9fa5]{1,5}/g;
        if (value !== '' && res.test(value)) {
          this.name.isValue = true;
        } else {
          this.name.isValue = false;
          this.$tipsAlert('请输入正确的姓名');
        }
        this.isUpdatas();
      },
      onTel(value) {
        const res = /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/;
        if (value !== '' && res.test(value)) {
          this.tel.isValue = true;
          this.codeTel = value;
        } else {
          this.codeTel = '';
          this.tel.isValue = false;
          this.$tipsAlert('请输入正确的手机号');
        }
        this.isUpdatas();
      },
      onCode(value) {
        if (value !== '' && value.length === 6) {
          this.code.isValue = true;
        } else {
          this.code.isValue = false;
          this.$tipsAlert('请输入正确的验证码');
        }
        this.isUpdatas();
      },
      isUpdatas() {
        if (this.name.isValue && this.tel.isValue && this.code.isValue) {
          this.isUpdate = true;
          this.btnType = 'btn-primary';
        } else {
          this.isUpdate = false;
          this.btnType = 'btn-disabled';
        }
      },
      async onUpData() {
        if (!this.name.isValue) {
          this.onName(this.name.value);
        }
        if (this.isUpdate) {
          const res = await checkPhoneE(this.tel.value);
          if (res.status * 1 === 1) {
            const param = {
              name: this.name.value,
              mobile: this.tel.value,
              code: this.code.value,
            };
            const upRes = await upSave(param);
            if (upRes.status * 1 === 1) {
              this.setUsrName(this.name.value);
              this.setLoginName(this.name.value);
              this.setLoginTel(this.tel.value);
              this.$router.push({ path: '/member/loginSelect' });
            } else {
              this.$tipsAlert(upRes.data.message);
            }
          } else {
            this.$tipsAlert('手机号已注册');
          }
        } else if (!this.name.isValue) {
          this.$tipsAlert('请输入正确的姓名');
        } else if (!this.tel.isValue) {
          this.$tipsAlert('请输入正确的手机号');
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  @import '~assets/styles/variable';
  .form {
    position: relative;
    width: 544px;
    margin: 0 auto;

    .form-input {
      margin-bottom: 28px;
    }

    .form-icon{
      position: absolute;
      top: 0;
      left: 0;
      width: 94px;
      height: 100px;
    }
  }
  .login-cont {
    width: 600px;
    margin: 56px auto 0;
  }

  .login-select{
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: $default-body-background;
  }
</style>
