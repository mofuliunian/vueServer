<template>
<div class="my-card">
  <img src="../../../../static/images/test_2.jpg" class="card-img" alt="">
  <div class="card-select" @click="onGetCard">{{cardText}} <img v-if="cardText == '请选择祝福语'" src="../../../../static/images/icon_jt.png" class="icon_jt" alt=""></div>
  <div class="login-cont"  @click="onUpData">
    <au-button :btnType="btnType" text="生成福卡"></au-button>
  </div>

  <div class="rule">
    <span></span>
    <h3>活动规则</h3>
    <div class="rule-content">
      <ul>
        <li>
          <i class="num">1</i>
          <span class="title">分享</span>
          <span class="text">生成福卡并分享给好友；</span>
        </li>
        <li>
          <i class="num">2</i>
          <span class="title">加入</span>
          <span class="text">好友可通过福卡加入圈圈汽车会员；</span>
        </li>
        <li>
          <i class="num">3</i>
          <span class="title">奖励</span>
          <span class="text" v-if="getUser.memberTitle == '会长'">好友加入成功后，你可获得会员费50%的现金奖励；</span>
          <span class="text" v-else>好友加入成功后，你可获得会员费10%的圈币奖励；</span>
        </li>
        <li CLASS="no-dashed">
          <i class="no-dashed"></i>
          <i class="num">4</i>
          <span class="title">{{getUser.memberTitle == '会长' ? '提现' : '领取'}}</span>
          <span class="text">{{getUser.memberTitle == '会长' ? '现金奖励可在圈圈汽车服务号内随时提取；' : '圈币奖励可在圈圈汽车服务号内随时领取；'}}</span>
        </li>
      </ul>
    </div>
  </div>

  <div class="select" v-if="isSelect">
    <div class="select-bg" @click="onGetCard"></div>
    <au-card @upDate="onUpDate"></au-card>
  </div>

  <div class="select" v-if="isCardImg">
    <div class="text">
      <img src="../../../../static/images/icon_card_1.png" alt="">
      <span>直接分享或长按保存后分享</span>
    </div>
    <img :src="cardImg" class="card-img-erw" alt="">
  </div>
</div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters, mapActions } from 'vuex';
  import auCard from 'base/select/card';
  import { menuShare } from '../../../utils/weixin';
  import { newCard, getMine } from '../../../api/request';

  export default {
    name: '',
    data() {
      return {
        isCard: false,
        isSelect: false,
        isCardImg: false,
        cardText: '请选择祝福语',
        btnType: 'btn-disabled btn-card',
        cardImg: '../../../../static/images/card_img.png',
        user: {},
      };
    },
    computed: {
      ...mapGetters([
        'getUser',
      ]),
    },
    components: {
      auCard,
    },
    methods: {
      ...mapActions([
        'setUsr',
        'setIsUser',
        'setWeixinUser',
      ]),
      onUpDate(val) {
        this.isCard = true;
        this.cardText = val;
        this.btnType = 'btn-primary btn-card';
        this.onGetCard();
      },
      onGetCard() {
        this.isSelect = !this.isSelect;
      },
      onUpData() {
        if (this.cardText !== '' && this.cardText !== '请选择祝福语') {
          this.newCards();
        } else {
          this.$tipsAlert('请选择祝福语');
        }
      },
      setSele() {
        this.isSelect = !this.isSelect;
      },
      async newCards() {
        const param = {
          content: this.cardText,
        };
        const res = await newCard(param);
        await this.getMineDate();
        if (res.status * 1 === 1) {
          this.cardImg = res.data.inviteCard;
          this.isCardImg = true;
          const line = `http://oocar.oojunzi.com/heo/?inviter_uid=${this.user.uid}#/member/index`;
          menuShare('加入圈圈汽车，驶入一个圈子的生意与生活', line, 'http://oocar.oojunzi.com/heo/dist/static/images/share.png', '给爱车保障，给朋友温度，我们不一样！');
        }
      },
      async getMineDate() {
        const res = await getMine();
        if (res.status * 1 === 1) {
          this.user = res.data;
          this.setUsr(res.data);
          this.setIsUser(true);
        } else if (res.data.code === -1) {
          this.$tipsAlert(res.data.message);
        } else {
          this.setIsUser(false);
          this.setWeixinUser(res.data);
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  .my-card {

  }
  .card-img {
    margin: 30px auto 62px;
    width: 706px;
  }
  .card-select {
    position: relative;
    box-sizing: border-box;
    margin: 0 auto 46px;
    width: 706px;
    height: 100px;
    font-size: 34px;
    text-indent: 50px;
    color: rgb(139,139,139);
    line-height: 100px;
    border: 1Px solid #8b8b8b;
    border-radius: 100px;
    background-color: #f9f9f9;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    padding-right: 20px;

    .icon_jt {
      position: absolute;
      top:35px;
      right: 62px;
      width: 16px;
      height: 30px;
    }
  }

  .rule {
    margin-top: 56px;

    & > span{
      display: block;
      height: 32px;
      background-color: #f8f8f8;
    }
    
    h3 {
      padding-top: 81px;
      padding-bottom: 58px;
      text-align: center;
      color: rgb(81,81,81);
      font-size: 48px;
    }
  }

  .rule-content {
    margin-left: 52px;

    ul {
      padding-left: 10px;
    }

    li {
      position: relative;
      padding-bottom: 58px;
      border-left: 1Px dashed #505050;

      &.no-dashed{
        border-color: #FFF;
       }

      span {
        display: block;
        margin-left: 50px;
      }



      .num {
        position: absolute;
        top: 0;
        left: -11pX;
        width: 44px;
        height: 44px;
        text-align: center;
        line-height: 44px;
        border-radius: 44px;
        background-color: #505050;
        color: #ffffff;
        font-style: normal;
      }



      .title {
        padding-top: 8px;
        margin-bottom: 14px;
        font-size: 36px;
        color: rgb(81,81,81);
      }

      .text {
        width: 540px;
        font-size: 30px;
        line-height: 48px;
        color: rgb(139,139,139);
      }
    }
  }

  .select {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    overflow: hidden;
    background-color: rgba(0,0,0,0.4);

    .text {
      position: absolute;
      top: 6px;
      right: 54px;
      font-size: 28px;
      color: #f3d798;
      z-index: 9;

      img {
        margin:0 auto 0px;
        padding-left: 90px;
        width: 93px;
      }
    }

    .select-bg {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
    }
  }

  .card-img-erw {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 614px;
  }
</style>        
