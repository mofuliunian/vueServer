<template>
<div class="login-success">
  <img src="../../../../static/images/success_1.png" class="login-icon-success" alt="">
  <p class="success-text">加入成功</p>
  <div class="login-apy-content">
    <div>
      <span class="left">支付时间</span>
      <span class="right">{{data.createDate || times}}</span>
    </div>
    <div>
      <span class="left">支付金额</span>
      <span class="right">{{getMemberJoin.money}}</span>
    </div>
  </div>
  <div class="card">
    <img src="../../../../static/images/test_2.jpg" alt="" @click="goCard">
    <div class="td-code">
      <img src="../../../../static/images/code_bg.png" class="code-bg" alt="">
      <img src="../../../../static/images/qrcode.jpg" class="td-code-img" alt="">
    </div>
    <div class="code-tips">重要！！！请关注圈圈汽车会员服务号</div>
  </div>
</div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters, mapActions } from 'vuex';
  import { getMine, getQueryOrder } from '../../../api/request';

  export default {
    name: '',
    data() {
      return {
        message: {
          1: '支付失败',
          2: '转入退款',
          3: '未支付',
          4: '已关闭',
          5: '已撤销（刷卡支付）',
          6: '用户支付中',
          7: '支付失败(其他原因，如银行返回失败)',
        },
        times: '',
        data: {},
      };
    },
    created() {
      this.times = `${new Date().getFullYear()}-${new Date().getMonth() + 1}-${new Date().getDate()}`;
      this.getQueryOrders();
    },
    computed: {
      ...mapGetters([
        'getMemberJoin',
      ]),
    },
    methods: {
      ...mapActions([
        'setUsr',
        'setIsUser',
        'setWeixinUser',
      ]),
      goCard() {
        this.$router.push({ path: '/member/loginCard' });
      },
      async getQueryOrders() {
        const param = {
          outTradeNo: this.setMemberJoin.outTradeNo,
        };
        const res = await getQueryOrder(param);
        if (res.status * 1 === 1) {
          this.data = res.data;
          this.getMineDate();
        } else {
          this.$alert(this.message[res.data.code]);
        }
      },
      async getMineDate() {
        const res = await getMine();
        if (res.status * 1 === 1) {
          this.setUsr(res.data);
          this.setIsUser(true);
        } else if (res.data.code === -1) {
          this.$tipsAlert(res.data.message);
        } else {
          this.setIsUser(false);
          this.setWeixinUser(res.data);
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  .login-icon-success {
    margin: 60px auto 25px;
    width: 189px;
  }
  .success-text {
    margin-bottom: 64px;
    text-align: center;
    font-size: 42px;
    color: #7b7b7b;
  }

  .login-apy-content {
    width: 586px;
    margin: 0 auto 108px;
    font-size: 30px;

    & > div {
      position: relative;
      margin-bottom: 50px;
    }

    .left {
      display: block;
      color: rgb(81,81,81);
    }

    .right {
      position: absolute;
      top: 0;
      right: 0;
      color: rgb(139,139,139);
    }
  }

  .card {
    margin: 0 auto;
    width: 706px;
  }

  .td-code {
    position: relative;
    margin: 60px auto 40px;
    width: 316px;
    height: 316px;

    .td-code-img {
      position: absolute;
      top: 27px;
      left: 27px;
      width: 262px;
    }
  }

  .code-tips {
    padding-bottom: 52px;
    text-align: center;
    font-size: 32px;
    color: rgb(102,102,102);
  }
</style>        
