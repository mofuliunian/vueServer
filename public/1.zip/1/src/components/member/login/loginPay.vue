<template>
  <transition name="fade">
    <div class="login-pay">
      <img src="../../../../static/images/pay-top.png" alt="">
      <div class="login-pay-contetn">
        <div class="login-pay-banner">
          <img src="../../../../static/images/test_1.jpg" alt="">

          <div class="login-banner-text">
            <h3>{{getLogin.vehicle.brandName}}宣言</h3>
            <span class="solid"></span>
            <div class="flex login-text-cont">
              <div v-for="(item, index) in getMemberJoin.carSlogan" v-if="index < 3">{{item}}</div>
            </div>
          </div>
          <div class="login-pay-add">你将成为第<span>{{getMemberJoin.membershipNo}}</span>位成员</div>
        </div>
      </div>

      <div class="login-pay-price">
        <div class="price">{{getMemberJoin.money}}</div>
        <div class="price-tips">会费标准(￥)</div>
      </div>

      <div class="login-cont" @click="onUpData">
        <au-button :btnType="btnType" text="支付入会"></au-button>
      </div>
    </div>
  </transition>
</template>

<script type="text/ecmascript-6">
  import { mapGetters } from 'vuex';
  import bridgeReady from '../../../utils/bridgeReady';
  import { getPrices } from '../../../api/request';

  export default {
    name: '',
    mixins: [bridgeReady],
    data() {
      return {
        type: 'xxl',
        img: 'https://si.geilicdn.com/bj-vshop-906482644-1500950826188-559309623_1080_810.jpg?w=110&h=110&cp=1',
        className: 'from-wrap-xxl',
        isSelect: false,
        textList: [],
        btnType: 'btn-primary',
        price: '',
        membercnt: 1,
        paySign: {
          packages: '',
          signType: '',
          paySign: '',
        },
      };
    },
    computed: {
      ...mapGetters([
        'getUser',
        'getLogin',
        'getPaySign',
        'getMemberCnt',
        'getMemberJoin',
      ]),
    },
    created() {
      if ((!this.getMemberJoin.money || this.getMemberJoin.membershipNo)
              && !this.getLogin.tel && !this.getLogin.name) {
        this.$router.push({ path: '/member/newLogin' });
      }
      this.getPricess();
    },
    methods: {
      onUpData() {
        this.bridgeReady();
      },
      brandSuccess() {
        this.$router.push({ path: '/member/loginSuccess' });
      },
      async getPricess() {
        const res = await getPrices();
        const self = this;
        if (res.status * 1 === 1) {
          const brandList = res.data.priceRange;
          Object.keys(brandList).forEach((key) => {
            const keys = key.split('-');
            if (self.getLogin.price * 1 > keys[0] && self.getLogin.price * 1 < keys[1]) {
              self.price = brandList[key];
            }
          });
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  @import '~assets/styles/variable';
  .login-pay{
    overflow: hidden;

    .login-pay-contetn {
      position: absolute;
      top: 40px;
      width: 100%;
    }

    .login-pay-banner {
      width: 706px;
      margin: 0 auto;
    }

    .login-banner-text {
      position: absolute;
      top: 112px;
      text-align: center;
      width: 706px;

      h3 {
        margin-bottom: 35px;
        font-size: 44px;
        color: $default-body-background;
      }

      .solid {
        display: block;
        margin:0 auto 46px;
        width: 106px;
        height: 2Px;
        background-color: $default-body-background;
      }

      .login-text-cont {
        width: 706px;
        align-items: center;
        justify-content:space-between;
        -webkit-flex-direction: row;
        -ms-flex-direction: row;
        flex-direction: row;
        -webkit-box-orient: horizontal;

        div {
          width: 33.3%;
          font-size: 46px;
          color: $default-body-background;
        }
      }
    }

    .login-pay-add {
      text-align: center;
      margin-top: 65px;
      font-size: 32px;
      color: rgb(81,81,81);

      span {
        vertical-align: text-bottom;
        font-size: 44px;
        color: rgb(251,191,57);
      }
    }
  }

  .login-pay-price {
    text-align: center;
    margin-top: 98px;

    .price {
      margin-bottom: 20px;
      font-size: 80px;
      color: rgb(251,191,57);
    }
    .price-tips {
      margin-bottom: 80px;
      font-size: 24px;
      color: rgb(139,139,139);
    }
  }

  @-webkit-keyframes fadeInRight {
    from {
      opacity: 0;
      -webkit-transform: translate3d(100%, 0, 0);
      transform: translate3d(100%, 0, 0);
    }

    to {
      opacity: 1;
      -webkit-transform: none;
      transform: none;
    }
  }

  @keyframes fadeInRight {
    from {
      opacity: 0;
      -webkit-transform: translate3d(100%, 0, 0);
      transform: translate3d(100%, 0, 0);
    }

    to {
      opacity: 1;
      -webkit-transform: none;
      transform: none;
    }
  }

  .fade-enter-active {
    -webkit-animation-name: fadeInRight;
    animation-name: fadeInRight;
    -webkit-animation-duration: 0.5s;
    animation-duration: 0.5s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
  }

</style>        
