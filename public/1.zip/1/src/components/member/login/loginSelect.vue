<template>
  <transition name="fade">
    <div class="login-select">
      <img src="../../../../static/images/bg_1.jpg" alt="">
      <div class="login-user-img">
        <au-userimg :imgSrc="getUser.avatar || getWXUser.avatar" class="user-img-content" :types="type"></au-userimg>
      </div>
      <div class="name">Hi, {{getLogin.name}}</div>
      <div class="select-input">
        <div class="select-input-content">
          <au-input
                  v-model="vehicle.value"
                  class="form-input"
                  :maxLength="vehicle.length"
                  :placeholder="vehicle.placeholder"
                  :className="className"
                  @handleBlur="onVehicle">
            <i class="form-icon-xxl icon-vehicle"></i>
          </au-input>
          <div class="select-vehicles" @click="setSele"></div>
        </div>

        <div class="select-input-content">
          <au-input
                  v-model="price.value"
                  class="form-input"
                  :type="'tel'"
                  :maxLength="price.length"
                  :placeholder="price.placeholder"
                  :className="className"
                  @handleBlur="onPrice">
            <i class="form-icon-xxl icon-price"></i>
            <i class="icon-price-d" v-if="price.value != ''">万</i>
          </au-input>
        </div>

        <div class="tips">*请填写正确的价格，否则将影响你的会员权益</div>
        <div class="login-cont"  @click="onUpData">
          <au-button :btnType="btnType" text="下一步"></au-button>
        </div>
      </div>

      <div class="select" v-if="isSelect" >
        <div class="select-bg" @click="setSele"></div>
        <au-vehicle @upDate="onVehicletext"></au-vehicle>
      </div>
    </div>
  </transition>
</template>

<script type="text/ecmascript-6">
  import { mapGetters, mapActions } from 'vuex';
  import auUserimg from 'base/userimg/userimg';
  import auVehicle from 'base/select/vehicle';
  import { getJoin } from '../../../api/request';

  export default {
    name: '',
    data() {
      return {
        type: 'xxl',
        img: 'https://si.geilicdn.com/bj-vshop-906482644-1500950826188-559309623_1080_810.jpg?w=110&h=110&cp=1',
        className: 'from-wrap-xxl',
        isSelect: false,
        vehicle: {
          value: '',
          length: 50,
          placeholder: '请选择你的爱车品牌',
          isValue: false,
        },
        price: {
          value: '',
          length: 8,
          placeholder: '请输入爱车的购买价格',
          isValue: false,
        },
        brandId: -1,
        btnType: 'btn-disabled',
      };
    },
    computed: {
      ...mapGetters([
        'getUser',
        'getLogin',
        'getWXUser',
      ]),
    },
    components: {
      auUserimg,
      auVehicle,
    },
    methods: {
      ...mapActions([
        'setPaySign',
        'setLoginVehicle',
        'setLoginPrice',
        'setBrandSlogan',
        'setMemberCnt',
        'setMemberJoin',
      ]),
      onVehicletext(vaule) {
        if (vaule) {
          this.vehicle.value = vaule.brandName;
          this.brandId = vaule.id;
          this.vehicle.isValue = true;
          this.setSele();
          this.setLoginVehicle(vaule);
        }
      },
      onVehicle(vaule) {
        if (vaule !== '') {
          this.vehicle.isValue = true;
        } else {
          this.vehicle.isValue = false;
          this.$tipsAlert('请选汽车品牌');
        }
        this.isUpdatas();
      },
      onPrice(vaule) {
        const res = /^\+?[1-9][0-9]*$/g;
        if (vaule !== '' && res.test(vaule)) {
          this.price.isValue = true;
        } else {
          this.price.isValue = false;
          this.$tipsAlert('请输入正确数字');
        }
        this.isUpdatas();
      },
      isUpdatas() {
        if (this.vehicle.isValue && this.price.isValue) {
          this.isUpdate = true;
          this.btnType = 'btn-primary';
        } else {
          this.isUpdate = false;
          this.btnType = 'btn-disabled';
        }
      },
      setSele() {
        this.isSelect = !this.isSelect;
      },
      async onUpData() {
        if (this.isUpdate) {
          const param = {
            carBrandId: this.brandId,
            price: this.price.value,
          };

          const res = await getJoin(param);
          if (res.status * 1 === 1) {
            this.setPaySign(res.data.paySign);
            this.setLoginPrice(res.data.money);
            this.setBrandSlogan(res.data.carSlogan);
            this.setMemberCnt(res.data.membershipNo);
            this.setMemberJoin(res.data);
            this.$router.push({ path: '/member/loginPay' });
          } else {
            this.$tipsAlert(res.data.message);
          }
        } else if (!this.price.isValue) {
          this.$tipsAlert('请输入正确数字');
        } else if (this.vehicle.isValue) {
          this.$tipsAlert('请选汽车品牌');
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  @import '~assets/styles/variable';
  .login-select {
    width: 100%;
    height: 100%;
  }
  .name {
    font-size: 36px;
    color: $index-color-text;
    text-align: center;
  }
  .login-user-img {
    position: absolute;
    top: 55px;
    width: 100%;

    .user-img-content {
      width: 326px;
      margin: 0 auto;
    }
  }
  .form-icon-xxl {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 110px;
    height: 100px;
  }
  .name {
    margin-bottom: 110px;
    font-size: 36px;
    color: rgb(81,81,81);
  }
  .select-input {
    width: 600px;
    margin: 0 auto;
  }
  .select-input-content {
    width: 600px;
    position: relative;

    .form-input {
      margin-bottom: 28px;
    }

    .icon-price-d {
      position: absolute;
      top: 0;
      right: 0;
      width: 110px;
      text-align: center;
      height: 100px;
      line-height: 100px;
      font-size: 28px;
      font-style: normal;
      color: #222222;
    }

    .select-vehicles {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index:9;
    }
  }
  .tips {
    margin-top: 2px;
    margin-bottom: 70px;
    font-size: 24px;
    color: rgb(204,204,204);
  }

  .select {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.4);

    .select-bg {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
    }
  }

  @-webkit-keyframes fadeInUp {
    from {
      opacity: 0;
      -webkit-transform: translate3d(0, 100%, 0);
      transform: translate3d(0, 100%, 0);
    }

    to {
      opacity: 1;
      -webkit-transform: none;
      transform: none;
    }
  }

  @keyframes fadeInUp {
    from {
      opacity: 0;
      -webkit-transform: translate3d(0, 100%, 0);
      transform: translate3d(0, 100%, 0);
    }

    to {
      opacity: 1;
      -webkit-transform: none;
      transform: none;
    }
  }

  .fade-enter-active {
    -webkit-animation-name: fadeInUp;
    animation-name: fadeInUp;
    -webkit-animation-duration: 0.5s;
    animation-duration: 0.5s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
  }
</style>        
