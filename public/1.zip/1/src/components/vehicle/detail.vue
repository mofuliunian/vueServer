<template>
  <div class="detail">
    <div class="detail-top">
      <img src="../../../static/images/detail_top.jpg" alt="">
      <div class="detail-top-text">
        <span class="text-ve">已加入车辆（辆）</span>
        <span class="ve-num">{{num}}</span>
        <span class="add-ve-num">本月新增{{addNum}}辆</span>
      </div>
    </div>
    <div class="detail-btn">
      <img src="../../../static/images/detail_btn_bg.png" alt="">
      <div class="detail-btn-text">圈圈用户安全行驶累积 <span>{{times}}</span> h</div>
    </div>

    <div class="detail-list">
      <h3 class="flex">
        <i></i>
        <span>为什么选择圈圈互助</span>
        <i></i>
      </h3>

      <ul class="flex detail-list-content">
        <li>
          <img src="../../../static/images/detel_icon_1.png" alt="">
          <span class="list-title">保险范围窄</span>
          <span class="list-content">各种险种都要买</span>
        </li>
        <li class="contents">
          <img src="../../../static/images/detel_icon_2.png" alt="">
          <span class="list-title">价格不菲</span>
          <span class="list-content">不出险也要掏钱</span>
        </li>
        <li>
          <img src="../../../static/images/detel_icon_3.png" alt="">
          <span class="list-title">不敢出险</span>
          <span class="list-content">出险保费就上涨</span>
        </li>
      </ul>
    </div>
    <div class="detail-bg">
      <div class="detail-list">
        <h3 class="flex">
          <i></i>
          <span>成为圈圈会员</span>
          <i></i>
        </h3>

        <div class="detail-list-img">
          <img src="../../../static/images/my_detail.jpg" alt="">
          <img src="../../../static/images/my_detail_1.jpg" alt="">
          <img src="../../../static/images/my_detail_3.jpg" alt="">
        </div>
      </div>

      <div class="detail-list">
        <h3 class="flex">
          <i></i>
          <span>了解互助规则</span>
          <i></i>
        </h3>

        <div class="rule-content">
          <ul>
            <li>
              <i class="no-dashed-top"></i>
              <i class="num"></i>
              <span class="title" @click="onSelect(0)">
                <span>适用车辆</span>支持0至10年的机动车辆
                <img src="../../../static/images/icon_btn_top.png" v-if="isSelect == 0" alt="">
                <img src="../../../static/images/icon_btn_botton.png"  v-if="isSelect != 0" alt="">
              </span>
              <span class="text" v-if="isSelect == 0">
                1.机动车车龄范围为0至10年(含);<br>
                2.机动车使用性质为非营运;<br>
                3.机动车为七座（含）以下;<br>
                4.目前开通北京，上海，苏州三地，含在以上地区长期行驶的外地车辆。
              </span>
            </li>
            <li>
              <i class="num"></i>
              <span class="title" @click="onSelect(1)">
                <span>互助范围</span>
                意外产生的损失
                <img src="../../../static/images/icon_btn_top.png" v-if="isSelect == 1" alt="">
                <img src="../../../static/images/icon_btn_botton.png"  v-if="isSelect != 1" alt="">
              </span>
              <span class="text" v-if="isSelect == 1">1.互助期间内，因意外事故或自然灾害造成会员车直接损失;<br>
                2.具体包含：碰撞损坏\车身划伤\水淹\玻璃破碎\盗抢\自燃\倒车镜损坏。
              </span>
            </li>
            <li>
              <i class="num"></i>
              <span class="title" @click="onSelect(2)">
                <span>维修服务</span> 指定修理厂及4S店共309家
                <img src="../../../static/images/icon_btn_top.png" v-if="isSelect == 2" alt="">
                <img src="../../../static/images/icon_btn_botton.png"  v-if="isSelect != 2" alt="">
              </span>
              <span class="text" v-if="isSelect == 2">支持对45个主流汽车品牌的修车服务</span>
            </li>
            <li CLASS="no-dashed">
              <i class="no-dashed"></i>
              <i class="num"></i>
              <span class="title" @click="onSelect(3)">
                <span>互助额度</span>周分摊约3元-20元，年分摊约1040元
                <img src="../../../static/images/icon_btn_top.png" v-if="isSelect == 3" alt="">
                <img src="../../../static/images/icon_btn_botton.png"  v-if="isSelect != 3" alt="">
              </span>
              <span class="text" v-if="isSelect == 3">按实际价值互助（会员车单次损失的修复费用以及救援费用合计不超过事故发生时该车的市场价值）。</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="detail-list-last">
      <div class="detail-list">
        <h3 class="flex">
          <i></i>
          <span>媒体追踪</span>
          <i></i>
        </h3>
        <div class="flex detail-logoin">
          <img src="../../../static/images/qin.jpg" alt="">
          <img src="../../../static/images/wy.jpg" alt="">
          <img src="../../../static/images/xl.jpg" alt="">
          <img src="../../../static/images/fh.jpg" alt="">
        </div>
      </div>
    </div>



    <div class="btn" @click="onVehicle">
      立即加入
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { getTotalCars } from '../../api/request';

  export default {
    name: '',
    data() {
      return {
        num: 78987,
        addNum: 119,
        times: 70000,
        isSelect: 0,
      };
    },
    created() {
      this.getTotalInfo();
    },
    methods: {
      onSelect(index) {
        this.isSelect = index;
      },
      onVehicle() {
        this.$router.push({ path: '/vehicle/vehAdd' });
      },
      async getTotalInfo() {
        const res = await getTotalCars();
        const self = this;
        if (res.status * 1 === 1) {
          self.num = res.data.total_car;
          self.addNum = res.data.month_car;
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  .detail-bg {
    padding-top: 26px;
    background-color: #f9f9f9;

    .detail-list {
      margin-bottom: 26px;
    }
  }
  .detail-top {
    position: relative;
    color: #FFF;

    .detail-top-text {
      position: absolute;
      top: 82px;
      left: 0;
      width: 100%;
      text-align: center;

      span {
        display: block;
      }

      .text-ve {
        margin-bottom: 24px;
        font-size: 20px;
      }

      .ve-num {
        margin-bottom: 58px;
        font-size: 70px;
        font-weight: bold;
      }

      .add-ve-num {
        font-size: 26px;
      }
    }
  }

  .detail-btn {
    position: relative;
    z-index: 9;
    width: 574px;
    height: 122px;
    margin: -61px auto 10px;

    .detail-btn-text {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 122px;
      text-align: center;
      font-size: 30px;
      line-height: 122px;
      color: rgb(111,156,252);

      span {
        font-size: 36px;
        font-weight: bold;
      }
    }
  }
  
  .detail-list {
    padding-top: 86px;
    background-color: #FFF;
    h3 {
      margin-bottom: 80px;
      font-size: 32px;
      color: rgb(68,68,68);
      text-align: center;
      flex-direction: row;
      justify-content: center;
      align-items: center;

      span {
        margin: 0 40px;
      }
      i {
        display: block;
        width: 23px;
        height: 4px;
        background-color: #cccccc;
      }
    }

    .detail-list-content {
      width: 648px;
      padding-bottom: 118px;
      margin: 0 auto;
      flex-direction: row;
      justify-content: space-between;

      li {
        width: 198px;

      span {
          display: block;
          text-align: center;
        }
      }

      img {
        width: 124px;
        margin: 0 auto 24px;
      }

      .list-title {
        margin-bottom: 20px;
        font-size: 30px;
        font-weight: 800;
        color: #444444;
      }

      .list-content {
        font-size: 28px;
        color: #666;
      }
    }
  }
  .detail-list-img {
    width: 647px;
    margin: 0 auto;
    padding-bottom: 76px;

    img {
      margin-bottom: 20px;
    }
  }

  .rule-content {
    margin-left: 52px;

  ul {
    padding-left: 10px;
  }

  li {
    position: relative;
    padding-bottom: 58px;
    border-left: 1Px solid #a4c7fe;

   .no-dashed{
     position: absolute;
     top: 7px;
     bottom: 0px;
     width: 10px;
     left: -5px;
     background-color: #FFF;
   }

   .no-dashed-top{
     position: absolute;
     top:0;
     width: 10px;
     height: 7px;
     left: -5px;
     background-color: #FFF;
   }

  & > span {
    display: block;
    margin-left: 20px;
  }



  .num {
    position: absolute;
    top: 6px;
    left: -8pX;
    width: 14px;
    height: 14px;
    text-align: center;
    border-radius: 44px;
    background-color: #4175d4;
  }



  .title {
    position: relative;
    margin-bottom: 32px;
    font-size: 26px;
    color: rgb(51,51,51);

    span {
      color: rgb(65,117,212);
      margin-right: 22px;
    }

    img {
      position: absolute;
      top: 6px;
      right: 56px;
      width: 25px;
    }
  }

  .text {
    width: 604px;
    font-size: 26px;
    line-height: 44px;
    color: rgb(119,119,119);
  }
  }
  }

  .detail-logoin{
    width: 620px;
    margin: 0 auto 38px;
    padding-bottom: 76px;
    flex-direction: row;
    justify-content: space-between;

    img {
      width: 120px;
      height: 120px;
      box-shadow: 0px 0px 7px #f8f8f8;
    }
  }

  .btn {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 98px;
    line-height: 98px;
    text-align: center;
    font-size: 34px;
    color: #FFF;
    background-color: #515151;
  }

  .detail-list-last {
    padding-bottom: 100px;
  }

</style>        
