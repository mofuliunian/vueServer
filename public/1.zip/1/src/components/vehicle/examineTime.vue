<template>
  <div class="ex-time">
    <img src="../../../static/images/time.jpg" class="ex-time-img" alt="">
    <div class="ex-time-cont">
      <div class="ex-time-cons">
        <h3>您可能由于以下原因未能马上开启互助</h3>
        <div class="ex-time-input">
          <select v-model="selectValue">
            <option value="我已经购买车险，等到期后加入">我已经购买车险，等到期后加入</option>
          </select>
          <img src="../../../static/images/icon_bottom.jpg" class="icon-select" alt="">
        </div>
      </div>

      <div class="ex-time-cons">
        <h3>设置时间</h3>
        <div class="ex-time-input" @click="showDatePicker">
          <span>{{time}}</span>
          <img src="../../../static/images/icon_time.jpg" class="icon-time" alt="">
        </div>
        <div class="tips">
          * 该时间不作为开启互助时间，<span>仅作为提醒时间</span>
        </div>
      </div>
    </div>
    <div class="tel">
      我有疑问？圈圈专属客服 <a href="tel:4009008023">400-900-8023</a>
    </div>

    <div class="btn" @click="onSetRemindTime">保存</div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters } from 'vuex';
  import picker from 'base/picker/index';
  import { setRemindTime } from '../../api/request';

  export default {
    name: '',
    data() {
      return {
        time: '年/月/日',
        times: '',
        selectValue: '我已经购买车险，等到期后加入',
      };
    },
    computed: {
      ...mapGetters([
        'getAddCar',
      ]),
    },
    methods: {
      onVehicle() {
        this.$router.push({ path: '/vehicle/mydetail' });
      },
      async onSetRemindTime() {
        if (!this.times) return;
        const param = {
          desc: this.selectValue,
          time: this.times,
          carId: this.getAddCar.planMember.id,
        };
        const res = await setRemindTime(param);
        if (res.status * 1 === 1) {
          this.onVehicle();
        } else {
          this.$tipsAlert(res.data.message);
        }
      },
      showDatePicker() {
        const self = this;
        /* eslint-disable*/
        const getYearArray = (offset) => {
          const currentYear = new Date().getFullYear();
          const yearArr = [];
          for(let i = currentYear; i <= currentYear + offset; i++) {
            yearArr.push(i);
          }
          return yearArr;
        }
        const getDayArray = (year, month) => {
          const tday = new Date(year, month, 0);
          const dayArr = [];
          for(let i = 1; i <= tday.getDate(); i++) {
            dayArr.push(i);
          }
          return dayArr;
        }
        picker({
          slots: [
            {
              type: 'data',
              flex: 1,
              values: getYearArray(3),
              textAlign: 'center',
              defaultValue: new Date().getFullYear(),
            },
            {
              type: 'divider',
              content: '-',
            },
            {
              type: 'data',
              flex: 1,
              values: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
              textAlign: 'center',
              defaultValue: new Date().getMonth() + 1,
            },
            {
              type: 'divider',
              content: '-',
            },
            {
              type: 'data',
              flex: 1,
              values: getDayArray(new Date().getFullYear(), new Date().getMonth() + 1),
              textAlign: 'center',
              defaultValue: new Date().getDate(),
            }
          ],
          onConfirm: (instance, datas) => {
            self.times = datas.slot0 + '-' + datas.slot2 + '-' + datas.slot4;
            self.time = datas.slot0 + '年' + datas.slot2 + '月' + datas.slot4 + '日';
            instance.value = false;
          },
          onChange: (instance, changeInfo) => {
            if(changeInfo.changedSlotIndex === 0 || changeInfo.changedSlotIndex === 2) {
              instance.setSlotValues(4, getDayArray(changeInfo.val.slot0, changeInfo.val.slot2, 0), changeInfo.val.slot4 - 1);
            }
          },
        });
      },
    },
  };
</script>

<style lang="scss" scoped>
  .ex-time {
    height: 100%;
    background-color: #f9f9f9;
  }
  .ex-time-img {
    margin-bottom: 22px;
  }

  .ex-time-cont {
    background-color: #FFF;
    padding-top: 20px;
  }

  .ex-time-cons {
    width: 576px;
    margin: 80px auto 0;

    h3 {
      margin-bottom: 38px;
      font-size: 28px;
      color: rgb(68,68,68);
    }

    .ex-time-input {
      position: relative;
      box-sizing: border-box;
      padding: 0 50px;
      height: 90px;
      line-height: 90px;
      color: rgb(153,153,153);
      background-color: #f9f9f9;

      span {
        display: block;
      }
    }

    select {
      -webkit-appearance:none;
      -moz-appearance:none;
      appearance:none;
      display: block;
      border: none;
      width: 100%;
      height: 90px;
      line-height: 90px;
      background-color: #f9f9f9;
      color: rgb(153,153,153);
    }
  }

  .icon-select {
    position: absolute;
    right: 48px;
    bottom: 39px;
    width: 21px;
  }

  .icon-time {
    position: absolute;
    right: 48px;
    bottom: 30px;
    width: 30px;
  }

  .tips {
    margin-top: 36px;
    padding-bottom: 138px;
    font-size: 24px;
    color: rgb(102,102,102);
    span {
      color: #666666;
    }
  }

  .tel {
    padding: 82px 0;
    text-align: center;
    font-size: 24px;
    color: rgb(153,153,153);

    a {
      color: #4c8ffd;
    }
  }

  .btn {
    width: 100%;
    height: 98px;
    line-height: 98px;
    text-align: center;
    font-size: 34px;
    color: #FFF;
    background-color: #515151;
  }
</style>        
