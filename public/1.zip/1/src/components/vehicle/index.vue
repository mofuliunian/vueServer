<template>
<div class="add-vehicle">
  <div class="user-content">
    <div class="user-text set-border">
      <span>真实姓名</span>
      <span>{{getUser.name || getLogin.name}}</span>
    </div>
    <div class="user-text">
      <span>手机号码</span>
      <span>{{getUser.mobile || getLogin.tel}}</span>
    </div>
  </div>

  <div class="up-imgs">
    <au-upveimg @upDate="onGetOcr"></au-upveimg>
  </div>

  <div class="tips">* 用于车辆信息记录及分摊计算</div>

  <div class="btn" @click="getregistUserAndAddCar">
    添加车辆
  </div>
</div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters, mapActions } from 'vuex';
  import auUpveimg from 'base/upimg/vehicle';
  import { registUserAndAddCar } from '../../api/request';

  export default {
    name: '',
    data() {
      return {
        name: '',
        mobile: '',
        driverInfo: {},
        imgUrl: '',
        isDriver: false,
      };
    },
    computed: {
      ...mapGetters([
        'getUser',
        'getLogin',
      ]),
    },
    components: {
      auUpveimg,
    },
    methods: {
      ...mapActions([
        'setAddCar',
      ]),
      onVehicle() {
        this.$router.push({ path: '/vehicle/vehicleSuccess' });
      },
      onGetOcr(data, isDriver) {
        this.isDriver = isDriver;
        this.imgUrl = data.imgUrl;
        this.driverInfo = data.driverLicenseInfo;
      },
      async getregistUserAndAddCar() {
        if (this.isDriver) {
          const param = {
            carPlate: this.driverInfo.carPlate,
            carVin: this.driverInfo.carVin,
            carBrand: this.driverInfo.carBrand,
            carCity: this.driverInfo.carCity,
            driveCreateDate: this.driverInfo.driveCreateDate,
            imgUrl: this.imgUrl,
          };
          const res = await registUserAndAddCar(param);
          if (res.status * 1 === 1) {
            this.setAddCar(res.data);
            this.onVehicle();
          }
        } else {
          this.$alert('请上传图片');
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  .add-vehicle {
    position: relative;
    height: 100%;
    padding-top: 33px;
    background-color: #f9f9f9;
    box-sizing: border-box;
  }

  .set-border {
    border-bottom: 1Px solid #f6f6f6;
  }
  .user-content {
    background-color: #FFF;

    .user-text {
      margin: 0 auto;
      width: 630px;
      padding: 44px 0;
      font-size: 28px;
      color: rgb(68,68,68);

      span {
        margin-right: 49px;
      }
    }
  }
  .up-imgs {
    width: 690px;
    position: relative;
    margin: 43px auto 0;
  }
  .tips {
    margin-top: 44px;
    padding-bottom: 200px;
    margin-left: 58px;
    font-size: 24px;
    color: rgb(153,153,153);
  }
  .btn {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    height: 98px;
    line-height: 98px;
    text-align: center;
    font-size: 34px;
    color: #FFF;
    background-color: #515151;
  }
</style>        
