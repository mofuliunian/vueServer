<template>
  <div class="ve-success">
    <div class="ve-success-top">
      <div class="ve-p">
        <img src="../../../static/images/ve-success.png" alt="">
        <span class="text">{{getAddCar.carPlate}}</span>
      </div>
      <p>车辆添加成功</p>
    </div>
    <div class="ve-success-text">
      <h3>我们向你承诺</h3>
      <div class="ve-success-price">
        首次年度分摊上限仅  <span>¥{{getAddCar.planMember.yearShare}}</span>
      </div>
      <p>
        履职“满月”之际，回望习近平日夜兼程的足迹：2次视察调研，5次国内重要会议，10余场国内会见会谈，首访期间5天出席40多场双多边活动……一串串数字，有力诠释着讲话背后的实干决心。口言之，身必行之。”习近平以宏大的视野和全局的高度，擘画新时代的宏伟蓝图，写就实现中华民族伟大复兴的行动指南。习近平是规划者，也是践行者、领路人，步履不停、落子开局，带领中国走向新时代的豪迈征程。
      </p>
    </div>

    <div class="tips">
      <span>因你加入，互助更强大</span>
    </div>
    <div class="btn flex">
      <span @click="onVehicleTime" class="btn-time">定时开启</span>
      <span @click="onVehicle">开启互助吧</span>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters } from 'vuex';

  export default {
    name: '',
    data() {
      return {
        plate: '',
        price: '',
      };
    },
    computed: {
      ...mapGetters([
        'getAddCar',
      ]),
    },
    methods: {
      onVehicle() {
        this.$router.push({ path: '/vehicle/examine' });
      },
      onVehicleTime() {
        this.$router.push({ path: '/vehicle/examineTime' });
      },
    },
  };
</script>

<style lang="scss" scoped>
.ve-success {
  padding-top: 32px;
  background-color: #F9F9F9;
}
  .ve-success-top {
    padding-top: 48px;
    margin-bottom: 46px;
    background-color: #FFF;
    .ve-p {
      position: relative;
      margin: 0 auto 36px;
      width: 319px;
      height: 96px;

      .text {
        position: absolute;
        top: 0;
        left: 0;
        text-align: center;
        width: 319px;
        height: 96px;
        line-height: 96px;
        color: #FFF;
        font-size: 36px;
      }
    }

    p {
      padding-bottom: 54px;
      font-size: 32px;
      text-align: center;
      color: rgb(68,68,68);
    }
  }
  .ve-success-text {
    margin: 0 auto 60px;
    border-radius: 8px;
    text-align: center;
    width: 690px;
    background-color: #FFF;
    color: rgb(68,68,68);

    h3 {
      padding-top: 60px;
      margin-bottom: 57px;
      font-size: 32px;
    }

    .ve-success-price {
      margin-bottom: 40px;
      font-size: 28px;

      span {
        color: #4c8ffd;
      }
    }

    p {
      width: 624px;
      margin: 0 auto;
      text-align: left;
      font-size: 24px;
      line-height: 36px;
      color: rgb(102,102,102);
      padding-bottom: 127px;
    }
  }
  .tips {
    margin-bottom: 34px;
    height: 50px;

    span {
      border-radius: 50px 0 0 50px;
      padding-left: 36px;
      padding-right: 25px;
      background-color: #94b2fa;
      font-size: 24px;
      line-height: 50px;
      color: #FFF;
      float: right;
    }
  }
  .btn {
    text-align: center;
    font-size: 34px;
    color: #FFF;
    flex-direction: row;

    span {
      width: 472px;
      height: 98px;
      line-height: 98px;
      background-color: #515151;
    }

    .btn-time {
      width: 278px;
      background-color: #cccccc;
    }
  }
</style>        
