<template>
<div class="ve-examine">
  <div class="ve-examine-top">
    <p class="ve-text">为保护圈友的权益，加入车辆须通过审核</p>
    <p  class="ve-text">确保加入互助的车辆为正常状态</p>
    <div class="btn-code" @click="getCode" :class="{'btn-code-disabled': !isCode}">
      <div class="primary" v-if="isCode">
        获取验证码
      </div>
      <div class="disabled" v-else>
        <span class="code">{{codeNum}}</span>
        <span class="time">{{timeText}}后可重新获取</span>
      </div>
    </div>
    <div class="tips">＊根据获取的验证码顺序，比出相应数字手势点击示例图相机进行拍摄</div>
  </div>
  <div class="example" v-if="isCode">
    示例：拍摄验证码96750
  </div>
  <div class="sole" v-else></div>
  <div class="up-imgs">
    <div class="ex-img" v-for="(item, index) in content">
      <au-examine :key="index"
                  :codeNum="item.codeNum"
                  :text="item.tips"
                  :index="index"
                  @upDate="onUpDate"></au-examine>
    </div>

  </div>

  <div class="btn" @click="onSubAuditings">
    添加车辆
  </div>
</div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters } from 'vuex';
  import auExamine from 'base/upimg/exvehicle';
  import { subAuditing } from '../../api/request';

  export default {
    name: '',
    data() {
      return {
        isCode: true,
        codeNum: '',
        time: 30,
        timeText: '30分钟',
        timeObj: null,
        content: [
          {
            tips: '左前45角',
            codeNum: '',
            imgSrc: '',
          },
          {
            tips: '右前45度角',
            codeNum: '',
            imgSrc: '',
          },
          {
            tips: '左后45度角',
            codeNum: '',
            imgSrc: '',
          },
          {
            tips: '右后45度角',
            codeNum: '',
            imgSrc: '',
          },
          {
            tips: '车架号正面',
            codeNum: '',
            imgSrc: '',
          },
        ],
        imgList: [],
        isUp: true,
      };
    },
    components: {
      auExamine,
    },
    computed: {
      ...mapGetters([
        'getAddCar',
      ]),
    },
    methods: {
      getCode() {
        if (!this.isCode) return;
        const code = this.getCodes();
        const self = this;
        this.isCode = !this.isCode;
        this.content.forEach((item, index) => {
          this.content[index].codeNum = code[index];
        });
        this.codeNum = code;

        this.timeObj = setInterval(() => {
          self.time -= 1;
          if (self.time < 1) {
            clearInterval(self.timeObj);
            this.setTime();
          } else {
            self.timeText = `${self.time}分钟`;
          }
        }, 60000);
      },
      getCodes() {
        let code = '';
        for (let i = 0; i < 5; i += 1) {
          code += this.getRandom(0, 9);
        }
        return code;
      },
      getRandom(min, max) {
        const r = Math.random() * (max - min);
        const re = Math.round(r + min);
        const res = Math.max(Math.min(re, max), min);

        return res;
      },
      setTime() {
        const self = this;
        this.time = 60;
        this.timeObj = setInterval(() => {
          self.isTime = !this.isTime;
          self.time -= 1;
          self.timeText = `${self.time}s`;
          if (self.time < 0) {
            self.isCode = !self.isCode;
            self.time = 30;
            self.timeText = '30分钟';
            clearInterval(self.timeObj);
          }
        }, 1000);
      },
      onVehicle() {
        this.$router.push({ path: '/vehicle/mydetail' });
      },
      onUpDate(data, index) {
        this.content[index].imgSrc = data.url;
      },
      getImgList() {
        const list = [];
        this.content.forEach((itme) => {
          list.push(itme.imgSrc);
        });
        this.imgList = list;
      },
      onSubAuditings() {
        if (this.isUp) {
          this.isUp = false;
          this.onSubAuditing();
        }
      },
      async onSubAuditing() {
        this.getImgList();
        const param = {
          id: this.getAddCar.id, // 车辆 id
          code: this.codeNum,
          imgList: this.imgList,
        };

        if (this.imgList.length === 5) {
          const res = await subAuditing(param);
          this.isUp = true;
          if (res.status * 1 === 1) {
            this.onVehicle();
          }
        } else {
          this.$alert('请上传图片');
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  .ve-examine {
    padding-bottom: 98px;
    background-color: #f9f9f9;
  }
  .ve-examine-top {
    background-color: #FFF;
    padding-top: 31px;

    .ve-text {
      text-align: center;
      margin-top: 27px;
      font-size: 30px;
      color: rgb(68,68,68);
    }

    .btn-code {
      margin: 34px auto 24px;
      width: 510px;
      height: 112px;
      text-align: center;
      background-color: #515151;
      border-radius: 8px;
      color: #FFF;

      .primary {
        font-size: 34px;
        height: 112px;
        line-height: 112px;
      }

      .code {
        display: block;
        font-size: 36px;
        padding-top: 24px;
        margin-bottom: 16px;
      }
      .time {
        display: block;
        font-size: 22px;
      }

      &.btn-code-disabled{
        background-color: #cccccc;
      }

    }

    .tips {
      text-align: center;
      margin: 0 auto;
      width: 542px;
      font-size: 22px;
      line-height: 36px;
      padding-bottom: 28px;
    }
  }

  .ex-img {
    margin-bottom: 42px;
  }

  .sole {
    height: 45px;
  }

  .example {
    margin: 0 auto;
    padding: 32px 0;
    font-size: 22px;
    color: rgb(68,68,68);
    width: 690px;
  }

  .btn {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 98px;
    line-height: 98px;
    text-align: center;
    font-size: 34px;
    color: #FFF;
    background-color: #cccccc;
  }
</style>        
