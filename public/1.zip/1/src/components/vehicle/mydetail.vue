<template>
<div class="my-detail">
  <div class="my-list" v-for="(item, index) in list">
    <div class="my-list-content">
        <div class="my-list-titele">
          <img src="../../../static/images/icon_my.png" alt="">
          <span>{{item.carPlate}}</span>
        </div>
        <div class="my-list-cont" :class="{'my-list-cont-ensure': item.ispag == 4}">
          <div class="my-list-text">
            <span class="my-left">车辆品牌</span>
            <span class="my-right">{{item.carBrand}}</span>
          </div>
          <div class="my-list-text">
            <span class="my-left">分摊上线</span>
            <span class="my-right">￥{{item.planMember ? item.planMember.yearShare : ''}}</span>
          </div>
          <div class="my-list-text" v-if="item.planMember.isCheck == 10">
            <span class="my-left">定时开启</span>
            <span class="my-right" v-if="item.help && item.help.remind_time">{{item.help.remind_time}}</span>
            <span class="my-right" v-else @click="onVehicleTime(item)">设置</span>
          </div>
          <div class="my-list-text" v-if="item.planMember.isCheck == 40">
            <span class="my-left">审核失败</span>
            <span class="my-right">由于汽车照片不清晰，无法识别车辆信息，请您重新上传车辆行驶照片。</span>
          </div>
          <div class="my-list-text" v-if="item.planMember.isCheck == 30">
            <span class="my-left">审核说明</span>
            <span class="my-right">我们将在24h内完成此车辆审核，亲耐心等待。</span>
          </div>
        </div>
    </div>
    <div class="my-list-btn my-list-open" v-if="item.planMember.isCheck == 10" @click="onUpData(item)">
      马上开启
    </div>
    <div class="my-list-btn my-list-open-error" v-if="item.planMember.isCheck == 40" @click="onUpData(item)">
      重新审核
    </div>
    <div class="my-list-btn my-list-examine" v-if="item.planMember.isCheck == 30">
      审核中
    </div>
    <div class="my-list-btn my-list-ensure" v-if="item.planMember.isCheck == 20">
      <img src="../../../static/images/icon_btn_my.png" alt="">保障中
    </div>
  </div>
</div>
</template>

<script type="text/ecmascript-6">
  // 10未审核 30审核中 20审核通过 40审核失败
  import { mapActions } from 'vuex';
  import { getCarByUserId } from '../../api/request';

  export default {
    name: '',
    data() {
      return {
        list: [],
      };
    },
    created() {
      this.getMyCar();
    },
    methods: {
      ...mapActions([
        'setAddCar',
      ]),
      onUpData(item) {
        this.setAddCar(item);
        this.$router.push({ path: '/vehicle/examine' });
      },
      onVehicleTime(item) {
        this.setAddCar(item);
        this.$router.push({ path: '/vehicle/examineTime' });
      },
      async getMyCar() {
        const res = await getCarByUserId();
        if (res.status * 1 === 1) {
          this.list = res.data;
          if (this.list.length === 0) {
            this.$router.push({ path: '/vehicle/vehAdd' });
          }
        } else {
          this.$router.push({ path: '/vehicle/vehAdd' });
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  .my-detail {
    padding-top: 36px;
    background-color: #f9f9f9;
    padding-bottom: 1Px;
  }

  .my-list {
    position: relative;
    width: 710px;
    margin: 0 auto 35px;
    border-radius: 8px;
    background-color: #FFF;

    .my-list-content {
      width: 618px;
      margin: 0 auto;
    }

    .my-list-titele {
      padding: 35px 0;
      border-bottom: 1Px solid #f4f4f4;

      img {
        vertical-align: top;
        display: inline-block;
        width: 40px;
        margin-right: 16px;
      }

      span {
        display: inline-block;
        height: 40px;
        font-size: 36px;
        line-height: 40px;
        color: rgb(68,68,68);
      }
    }
  }

  .my-list-cont {
    margin-top: 76px;
    padding-bottom: 80px;

    &.my-list-cont-ensure {
     padding-bottom: 46px;
    }

    .my-list-text {
      position: relative;
      margin-bottom: 25px;
      font-size: 26px;
      color: rgb(153,153,153);
      line-height: 36px;
    }

    .my-left {
      position: absolute;
      top:0;
      left: 0;
    }

    .my-right {
      display: block;
      margin-left: 150px;
    }
  }

  .my-list-btn {
    position: absolute;
    bottom: 114px;
    right: 46px;
    width: 180px;
    height: 68px;
    line-height: 68px;
    font-size: 28px;
    color: #FFF;
    text-align: center;
    border-radius: 46px;

    img {
      display: inline-block;
      width: 28px;
      margin-top: 18px;
      margin-right: 6px;
      vertical-align: top;
    }
  }

  .my-list-open,
  .my-list-open-error{
    background-color: #4175d4;
  }

  .my-list-open-error,
  .my-list-examine{
    bottom: 182px;
  }

  .my-list-examine {
    background-color: #cccccc;
  }

  .my-list-ensure {
    bottom: 80px;
    background-color: #44bfa3;
  }
  .error {
    padding: 40px 0;
    text-align: center;
    color: rgb(68,68,68);
  }
</style>
