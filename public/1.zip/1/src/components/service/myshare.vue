<template>
<div class="share" >
  <div class="share-tab flex">
    <div :class="{'select-tab': istab == 0}" @click="onTab(0)">分摊金 <span v-if="istab == 0"></span></div>
    <div :class="{'select-tab': istab == 1}" @click="onTab(1)">会员费 <span v-if="istab == 1"></span></div>
  </div>
  <div class="share-pries" v-if="istab == 0">
    <div class="share-list" v-for="(item, index) in billList" v-if="false">
      <div class="share-list-contetn">
        <div class="share-list-num">
          您的第{{item.week_num}}期分摊帐单
        </div>
        <div class="time">{{item.ctime}}</div>
        <div class="count-down">
          分摊倒计时 <span>{{item.week_num}}</span> 天
        </div>
        <span class="line"></span>
        <div class="btns">
          <div class="pries">{{item.money}}元</div>
          <div class="share-btns-list flex">
            <div class="share-btns share-btns-detail"> 明细</div>
            <div class="share-btns">查看分摊</div>
            <div class="share-btns share-btns-disabled">已分摊</div>
          </div>
        </div>
      </div>
      <span class="round round-left"></span>
      <span class="round round-right"></span>
    </div>
    <div class="error">暂无</div>
  </div>

  <div class="user-pries" v-if="istab == 1">
    <div class="share-list user-share-list">
      <div class="share-list-contetn">
        <div class="share-list-num">
          会员费
        </div>
        <div class="time">{{getUser.createDate}}</div>
        <span class="line"></span>
        <div class="btns">
          <div class="pries">{{getUser.membershipFee}}元</div>
          <div class="share-btns-list flex">
            <div class="share-btns share-btns-disabled">已支付</div>
          </div>
        </div>
      </div>
      <span class="round round-left"></span>
      <span class="round round-right"></span>
    </div>
  </div>

</div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters } from 'vuex';
  import { billList } from '../../api/request';

  export default {
    name: '',
    data() {
      return {
        istab: 0,
        billList: [],
        userPries: {},
      };
    },
    created() {
      this.getMyBill();
    },
    computed: {
      ...mapGetters([
        'getUser',
      ]),
    },
    methods: {
      onTab(i) {
        this.istab = i;
      },
      async getMyBill() {
        const res = await billList();
        const self = this;
        if (res.status * 1 === 1) {
          self.billList = res.data;
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  .share {
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
    height: 100%;
    background-color: #f5f5f5;
  }
 .share-tab {
   height: 98px;
   margin-bottom: 16px;
   background-color: #FFF;
   flex-direction: row;

   div {
     position: relative;
     width: 50%;
     text-align: center;
     height: 98px;
     line-height: 98px;
     font-size: 24px;
     color: rgb(51,51,51);

     &.select-tab{
        color: rgb(65,117,212);
     }

     span {
       position: absolute;
       left: 50%;
       transform: translate(-50%, 0);
       bottom: 0;
        width: 40px;
        height: 6px;
        background-color: rgb(65,117,212);
       border-radius: 50px;
     }
   }
 }

  .error {
    width: 718px;
    padding: 40px 0;
    margin: 0 auto;
    background-color: #FFF;
    text-align: center;
    font-size: 22px;
    color: rgb(144,144,144);
  }

  .share-list {
    position: relative;
    width: 718px;
    padding-top: 50px;
    margin: 0 auto 16px;
    border-radius: 8px;
    background-color: #FFF;

    .round {
      position: absolute;
      top: 146px;
      width: 38px;
      height: 28px;
      border-radius: 28px;
      background-color: #f5f5f5;
    }

    .round-left {
      left: -18px;
    }
    .round-right {
      right: -18px;
    }
  }
  .share-list-contetn {
    position: relative;
    width: 630px;
    margin: 0 auto;

    .count-down {
      position: absolute;
      top: 0;
      right: 0;
      font-size: 22px;
      color: rgb(144,144,144);

      &.count-down-gules {
         color: #e74c3c;
      }

      span {
        font-size: 30px;
      }

      .green {
        color: #44bea3;
      }

      .gules {
        color: #e74c3c;
      }
    }

    .share-list-num {
      margin-bottom: 40px;
      font-size: 28px;
      color: rgb(51,51,51);
    }

    .time {
      margin-bottom: 72px;
      font-size: 22px;
      color: rgb(144,144,144);
    }

    .line {
      display: block;
      width: 618px;
      margin-left: 12px;
      height: 1Px;
      background-color: #cccccc;
    }

    .btns {
      position: relative;
      height: 104px;

      .pries {
        height: 104px;
        line-height: 104px;
        color: rgb(65,117,212);
      }

      .share-btns-list {
        position: absolute;
        right: 0px;
        top: 24px;
        flex-direction: row;
      }

      .share-btns {
        width: 168px;
        height: 58px;
        margin-right: 22px;
        line-height: 58px;
        color: #FFF;
        text-align: center;
        background-color: #4175d4;
        border-radius: 168px;
      }

      .share-btns-disabled {
        background-color: #d4d4d4;
      }

      .share-btns-detail {
        box-sizing: border-box;
        width: 122px;
        background-color: #FFF;
        border: 1Px solid #b1b1b1;
        color: #7a7a7a;
      }
    }
  }

  .user-share-list {
    padding-top: 42px;

    .share-list-num {
      margin-bottom: 30px;
    }

    .time {
      margin-bottom: 52px;
    }
  }
</style>        
