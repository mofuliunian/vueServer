<template>
  <div class="service-index">
    <div class="index-swiper" :class="{'disp-swiper-service': items.length == 0}">
      <swiper :options="swiperOption" ref="mySwiper" class="index-swiper-wrapper">
        <!-- 这部分放你要渲染的那些内容 -->
        <swiper-slide v-for="(item, index) in items" :key="item" class="slide-content">
          <img src="../../../static/images/service_banner_1.jpg" alt="">
        </swiper-slide>
        <!-- 这是轮播的小圆点 -->
          <div class="swiper-service" slot="pagination">
        </div>
      </swiper>
    </div>

    <div class="service-index-cont">
      <img src="../../../static/images/service_index_1.jpg" alt="">
      <div class="service-index-btn">
        <div class="btn" @click="getAddUser">
          加入会员
        </div>
      </div>
    </div>

    <div class="service-index-cont">
      <img src="../../../static/images/service_index_2.jpg" alt="">
      <div class="service-index-btn">
        <div class="btn" @click="goVehicle">
          开始互助
        </div>
      </div>
    </div>
    <div class="service-btn" @click="goMy">
      会员中心
    </div>

    <div class="service-alert" v-if="isalert">
      <div class="service-alert-cont">
        <div class="login-img">
          <img src="../../../static/images/login.png" alt="">
        </div>
        <div class="alert-cont-tips">
          开始加入圈圈汽车
        </div>
        <div class="service-alert-btn flex">
          <div class="service-alert-no" @click="isAlert">取消</div>
          <div class="service-alert-yes" @click="onYes">确定</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters, mapActions } from 'vuex';
  import { swiper, swiperSlide } from 'vue-awesome-swiper';

  export default {
    name: '',
    data() {
      return {
        items: [1],
        swiperOption: {
          pagination: {
            el: '.swiper-service',
            clickable: true,
          },
          notNextTick: true,
          slidesPerView: 'auto',
          centeredSlides: true,
          paginationClickable: true,
          autoplay: {
            delay: 1000,
            disableOnInteraction: false,
          },
          spaceBetween: 0,
        },
        isalert: false,
        isuser: false,
      };
    },
    computed: {
      ...mapGetters([
        'getUser',
      ]),
    },
    components: {
      swiper,
      swiperSlide,
    },
    methods: {
      ...mapActions([
        'setUsr',
        'setWeixinUser',
      ]),
      isAlert() {
        this.isalert = !this.isalert;
      },
      onYes() {
        this.$router.push({ path: '/member/index' });
      },
      getAddUser() {
        if (this.getUser.isMembership) {
          this.$router.push({ path: '/service/myService' });
        } else {
          this.isAlert();
        }
      },
      goVehicle() {
        if (this.getUser.isMembership) {
          this.$router.push({ path: '/vehicle/detail' });
        } else {
          this.isAlert();
        }
      },
      goMy() {
        if (this.getUser.isMembership) {
          this.$router.push({ path: '/service/myService' });
        } else {
          this.isAlert();
        }
      },
      goCard() {
        this.$router.push({ path: '/member/loginCard' });
      },
    },
  };
</script>

<style lang="scss" scoped>
  .index-swiper {
    position: relative;
    width: 750px;
    background-color: #f0f0f0;
    overflow: hidden;

    .slide-content {
      width: 750px;
    }
  }

  .service-index-cont {
    position: relative;
    height: 444px;
    margin-top: 30px;

    .service-index-btn {
      position: absolute;
      bottom: 30px;
      width: 100%;

      .btn {
        margin: 0 auto;
        width: 444px;
        height: 88px;
        line-height: 88px;
        font-size: 36px;
        text-align: center;
        color: rgb(251,191,57);
        background-color: rgba(255,255,255,0.3);
        border-radius: 88px;
      }
    }
  }

  .service-btn {
    margin-top: 30px;
    background-color: #515151;
    text-align: center;
    font-size: 36px;
    height: 124px;
    line-height: 124px;
    color: #FFF;
  }

  .service-alert {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }
  .service-alert-cont {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #FFF;
    width: 600px;
    border-radius: 8px;
  }
  .alert-cont-tips {
    padding: 124px 0 96px;
    text-align: center;
    font-size: 38px;
    color: rgb(81,81,81);
  }

  .login-img {
    position: absolute;
    top: -90px;
    width: 100%;

    img {
      width: 180px;
      margin: 0 auto;
    }
  }
  .service-alert-btn {
    flex-direction: row;

    div {
      width: 50%;
      height: 100px;
      font-size: 30px;
      line-height: 100px;
      text-align: center;
      color: #FFF;
    }

    .service-alert-no {
      background-color: #a0a0a0;
      border-radius: 0 0 0 8px;
    }
    .service-alert-yes {
      background-color: #515151;
      border-radius: 0 0 8px 0;
    }
  }
</style>
