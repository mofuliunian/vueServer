<template>
<div class="charge-money">
  <div class="charge-money-top">
    <div class="content">
      可用金币
      <div class="pries"><img src="../../../static/images/q.jpg" alt="">{{coin}}</div>
    </div>
  </div>
  <span class="line"></span>
  <div class="charge-money-content">
    <div class="charge-money-title">充值金额 <span>(1金币即1元)</span></div>

    <div class="input">
      <input type="tel" placeholder="请输入需要充值的金额，不能低于10元">
    </div>

    <div class="charge-money-list">
      <ul class="flex">
        <li v-for="(item, index) in list" :class="{'selse': isSelect == index}" @click="onSetPries(index)">
          <span class="list-pries">{{item.pries}}金币</span>
          <span class="list-tips">{{item.tips}}</span>
          <img v-if="isSelect == index" src="../../../static/images/money.png" alt="">
        </li>
      </ul>
    </div>

    <div class="btn" @click="onCharge()">
      立即充值
    </div>
  </div>
</div>
</template>

<script type="text/ecmascript-6">
  import { getBalance } from '../../api/request';

  export default {
    name: '',
    data() {
      return {
        coin: 0,
        list: [
          {
            pries: '50',
            tips: '送1元',
          },
          {
            pries: '100',
            tips: '首充送50元',
          },
          {
            pries: '200',
            tips: '首充送150元',
          },
          {
            pries: '300',
            tips: '送30元',
          },
          {
            pries: '400',
            tips: '送40元',
          },
          {
            pries: '500',
            tips: '送50元',
          },
        ],
        isSelect: 0,
      };
    },
    created() {
      this.getRemainCoin();
    },
    methods: {
      onSetPries(index) {
        this.isSelect = index;
      },
      onCharge() {
        this.$alert('充值功能下周开通~');
      },
      async getRemainCoin() {
        const res = await getBalance();
        const self = this;
        if (res.status * 1 === 1) {
          self.coin = res.data;
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  .line {
    height: 16px;
    width: 100%;
    background-color: #f5f5f5;
    display: block;
  }
  .charge-money-top {
    background-color: #FFF;
    height: 144px;
    line-height: 144px;

    .content {
      width: 625px;
      margin: 0 auto;
    }

    .pries {
      float: right;
      position: relative;

      img {
        position: absolute;
        left: -46px;
        bottom: 55px;
        width: 34px;
        max-width: 34px;
      }
    }
  }

  .charge-money-content {
    width: 625px;
    margin: 0 auto;
    color: rgb(51,51,51);
    font-size: 24px;

    .charge-money-title {
      margin-bottom: 60px;
      padding-top: 56px;
      span {
        color: rgb(212,212,212);
      }
    }

    .input {
      margin-bottom: 48px;
      input {
        display: block;
        text-align: center;
        width: 100%;
        height: 100px;
        line-height: 100px;
        color: rgb(212,212,212);
        border: none;
        background-color: #f5f5f5;
        border-radius: 8px;
      }
    }
  }

  .charge-money-list {
    ul {
      flex-wrap: wrap;
      flex-direction: row;
      justify-content: space-between;
    }

    li {
      position: relative;
      box-sizing: border-box;
      border: 1Px solid #f5f5f5;
      margin-bottom: 24px;
      width: 192px;
      height: 126px;
      text-align: center;
      border-radius: 8px;
      background-color: #f5f5f5;

      &.selse {
        background-color: #fff;
        border-color: #4175d4;
      }

       img {
         position: absolute;
         width: 53px;
         bottom: 0;
         right: 0;
       }

      span {
        display: block;
      }

      .list-pries {
        padding-top: 30px;
        margin-bottom: 17px;
        font-size: 26px;
      }
      .list-tips {
        color: rgb(65,117,212);
      }
    }
  }

  .btn {
    margin: 186px auto 0;
    width: 576px;
    height: 96px;
    line-height: 96px;
    color: #FFF;
    background-color: #515151;
    text-align: center;
    border-radius: 100px;
  }
</style>        
