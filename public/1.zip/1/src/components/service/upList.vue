<template>
  <div class="up-list">
    <ul v-if="list.length > 0">
      <li v-for="(item, index) in list">
        <div class="up-list-price">
          提现金额：
          <span>{{item.money}}元</span>
        </div>
        <div class="time">{{item.createDate}}</div>
        <span class="success">{{item.status == '0' ? '审核中' : '已成功'}}</span>
      </li>
    </ul>
    <div class="error" v-else>
      暂无提现
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { getWithdrawList, getUncompleted } from '../../api/request';

  export default {
    name: '',
    data() {
      return {
        list: [],
      };
    },
    created() {
      this.getHasUncompleted();
      this.getList(1);
    },
    methods: {
      async getList(page) {
        const res = await getWithdrawList(page);

        if (res.status * 1 === 1) {
          this.list = res.data.list;
        }
      },
      async getHasUncompleted() {
        const res = await getUncompleted();

        if (res.status * 1 === 1) {
          this.isHasUncompleted = res.data;

          if (res.data.hasUncompleted * 1 === 1) {
            this.$tipsAlert('您有正在审核的提现记录，提现成功后可以继续发起体现');
          }
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  .up-list {
    overflow-y: auto;
    width: 100%;
    height: 100%;
    background-color: #f8f8f8;

    li {
      position: relative;
      box-sizing: border-box;
      padding-left: 62px;
      margin-bottom: 20px;
      height: 170px;
      background-color: #FFF;
      font-size: 28px;
      color: rgb(139,139,139);

      .time {
        margin-top: 26px;
        font-size: 22px;
      }

      .success {
        position: absolute;
        top: 48px;
        right: 62px;
        color: rgb(251,191,57);
      }
    }

    .up-list-price {
      padding-top: 48px;

      span {
        color: #515151;
      }
    }
  }
  .error {
    padding: 30px 0;
    text-align: center;
    background-color: #FFF;
    font-size: 28px;
    color: rgb(139,139,139);
  }
</style>        
