<template>
<div class="share-detail">
  <div class="share-detail-content">
    <div class="title flex">
      <i></i>
      <span>分摊金</span>
      <i></i>
    </div>
    <div class="share-detail-p">100元</div>

    <div class="details">
      <span>公示期数</span>
      <span class="right">第02期</span>
    </div>

    <div class="details details-xl">
      <span>案件数量</span>
      <span class="right">6起</span>
    </div>

    <div class="details details-xxl">
      <span>分摊金</span>
      <span class="right">100元</span>
    </div>

    <div class="details details-l">
      <span>支付方式</span>
      <span class="right" v-if="iswx"><img src="../../../static/images/wx.png" alt=""> 微信支付</span>
      <span class="right" v-else><img src="../../../static/images/quan.png" alt=""> 圈圈金币</span>
    </div>

    <div class="details">
      <span>支付时间</span>
      <span class="right">2017年06月28日</span>
    </div>

    <div class="tps">如有疑问请联系圈圈客服 <br> 我们会为您耐心解答</div>
  </div>
</div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: '',
    data() {
      return {
        iswx: true,
      };
    },
  };
</script>

<style lang="scss" scoped>
  .share-detail {
    height: 100%;
    background-color: #f5f5f5;
  }
  .share-detail-content {
    width: 636px;
    margin: 0 auto;
    color: rgb(51,51,51);
    font-size: 26px;
  }
  .title {
    padding-top: 93px;
    margin-bottom: 80px;
    font-size: 24px;
    color: rgb(212,212,212);
    text-align: center;
    flex-direction: row;
    justify-content: center;
    align-items: center;

    span {
      margin: 0 33px;
    }

    i {
      display: block;
      width: 62px;
      height: 2Px;
      background-color: rgb(212,212,212);
    }
  }

  .share-detail-p {
    margin-bottom: 102px;
    font-size: 48px;
    color: rgb(51,51,51);
    text-align: center;
  }

  .details {
    margin-bottom: 44px;

    .right {
      position: relative;
      float: right;

      img {
        position: absolute;
        top: -7px;
        left: -60px;
        width: 40px;
        max-width: 40px;
      }
    }
  }

  .details-xl {
    margin-bottom: 76px;
  }

  .details-xxl {
    margin-bottom: 80px;
  }
  .details-l {
    margin-bottom: 48px;
  }

  .tps {
    margin-top: 286px;
    text-align: center;
    font-size: 24px;
    line-height: 36px;
    color: rgb(212,212,212);
  }
</style>        
