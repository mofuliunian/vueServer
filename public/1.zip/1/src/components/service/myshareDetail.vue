<template>
<div class="myshare-detail">
  <div class="myshare-detail-cont">
    <div class="title">
      第二期
    </div>
    <div class="time">2017年03月12日00:00－2017年03月24日24:00</div>
    <div class="list">
      <div class="vehicle">大众－京B732843</div>
      <div class="pries">分摊金 <span class="right">100.00元</span></div>
    </div>

    <div class="list">
      <div class="vehicle">凯迪拉克－京B732843</div>
      <div class="pries">分摊金 <span class="right">100.00元</span></div>
    </div>

    <div class="zhifu">
      <div class="zhifu-title">支付方式</div>
      <div class="zhifu-select flex">
        <img src="../../../static/images/quan.png" alt="">
        <span class="zhifu-name">圈圈金币</span>
        <span class="zhifu-tips">（账户金币不足）</span>
        <i>
          <img src="../../../static/images/share_1.jpg" v-if="isZhifu == 0" alt="">
          <img src="../../../static/images/share_2.jpg" v-else alt="">
        </i>
      </div>
      <div class="zhifu-select flex">
        <img src="../../../static/images/wx.png" alt="">
        <span class="zhifu-name">微信支付</span>
        <i>
          <img src="../../../static/images/share_1.jpg" v-if="isZhifu == 1" alt="">
          <img src="../../../static/images/share_2.jpg" v-else alt="">
        </i>
      </div>
    </div>
  </div>

  <div class="tips">圈圈互助已为您提供20天保障，为您节省1205.08元</div>
  <div class="myshare-btn flex">
    <div class="pries"><span>实际分摊 :</span> 100000元</div>
    <div class="bnts">去支付</div>
  </div>
</div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: '',
    data() {
      return {
        isZhifu: 0,
      };
    },
  };
</script>

<style lang="scss" scoped>
  .myshare-detail-cont {
    width: 544px;
    margin: 0 auto;
    font-size: 24px;
    color: rgb(51,51,51);

    .title {
      text-align: center;
      margin-bottom: 30px;
      padding-top: 46px;
      font-size: 36px;
      color: rgb(51,51,51);
    }

    .time {
      text-align: center;
      margin-bottom: 57px;
      font-size: 20px;
      color: rgb(212,212,212);
    }
  }
  .list {
    margin-bottom: 107px;
    .vehicle {
      margin-bottom: 40px;
    }

    .right {
      float: right;
    }
  }

  .zhifu {
    margin-bottom: 102px;
    margin-top: 224px;

    .zhifu-title {
      margin-bottom: 42px;
    }
  }

  .zhifu-select {
    position: relative;
    height: 61px;
    line-height: 61px;
    margin-bottom: 50px;
    flex-direction: row;

    img {
      width: 62px;
      margin-right: 33px;
    }
    
    .zhifu-tips {
      color: rgb(212,212,212);
    }

    i {
      position: absolute;
      top: 15px;
      right: 12px;
      width: 30px;
      height: 30px;
    }
  }

  .tips {
    margin-bottom: 140px;
    text-align: center;
    color: rgb(255,173,77);
  }

  .myshare-btn {
    position: absolute;
    width: 100%;
    bottom: 0;
    flex-direction: row;
    font-size: 26px;

    div {
      text-align: center;
      height: 100px;
      line-height: 100px;
      box-sizing: border-box;
      width: 50%;
      font-size: 28px;
      color: #FFF;
    }
    .bnts {
      background-color: #515151;
    }
    .pries {
      border-top: 1Px solid #e0e0e0;
      font-size: 26px;
      color: rgb(51,51,51);

      span {
        font-size: 30px;
        color: rgb(65,117,212);
      }
    }
  }
</style>        
