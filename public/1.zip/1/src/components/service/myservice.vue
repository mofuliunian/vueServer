<template>
<div class="my-service">
  <img src="../../../static/images/service_top.jpg" alt="">
  <div class="my-user">
    <div class="user-img">
      <div>
        <img :src="getUser.avatar" alt="">
      </div>
    </div>
    <div class="user-detail">
      <ul class="flex user-detail-list">
        <li>
          <span class="top">{{spareMoney.joinDays || '--'}}</span>
          <span class="bottom">加入(天)</span>
        </li>
        <li>
          <span class="top name">{{getUser.name}}</span>
          <span class="bottom">身份：{{getUser.memberTitle}}</span>
        </li>
        <li>
          <span class="top">{{spareMoney.shareAllMoney || '--'}}</span>
          <span class="bottom">节省（元）</span>
        </li>
      </ul>

      <div class="user-e">
        <span class="experience"><span :style="{width: (getUser.saveMoney/getUser.saveMoneyMax) * 100 + '%'}"></span></span>
        <span class="experience-num"><span>{{getUser.saveMoney}}</span> / {{getUser.saveMoneyMax}}</span>
      </div>
    </div>
  </div>

  <div class="my-list">
    <ul class="flex my-list-list">
      <li @click="onMyCoin">
        <img src="../../../static/images/icon-service_1.png" alt="">
        <span>圈圈金币</span>
      </li>
      <li @click="onCustomService">
        <img src="../../../static/images/icon-service_2.png" alt="">
        <span>联系客服</span>
      </li>
      <li @click="onMyCard">
        <img src="../../../static/images/icon-service_3.png" alt="">
        <span>赢取奖励</span>
      </li>
    </ul>
  </div>

  <div class="my-nav">
    <ul>
      <li @click="onMyMember" v-if="getUser.memberTitle == '会长'">
        <img src="../../../static/images/icon_service_9.png" class="icon_tips" alt="">
        <span>我的会员</span>
        <span class="my-nav-tips">{{getUser.memberCnt}}位，累计奖励<span>{{getUser.rewardCnt}}</span>元</span>
        <img src="../../../static/images/icon_service_8.png" class="icon_l" alt="">
      </li>
      <li @click="onMyMember" v-else>
        <img src="../../../static/images/icon_service_4.png" class="icon_tips" alt="">
        <span>我的伙伴</span>
        <span class="my-nav-tips">{{getUser.memberCnt}}位，累计奖励<span>{{getUser.rewardCnt}}枚</span>圈币</span>
        <img src="../../../static/images/icon_service_8.png" class="icon_l" alt="">
      </li>
      <li @click="onMyHelp">
        <img src="../../../static/images/icon_service_5.png" class="icon_tips" alt="">
        <span>我的互助</span>
        <img src="../../../static/images/icon_service_8.png" class="icon_l" alt="">
      </li>
      <li @click="onHelpInfo">
        <img src="../../../static/images/icon_service_6.png" class="icon_tips" alt="">
        <span>互助公示</span>
        <img src="../../../static/images/icon_service_8.png" class="icon_l" alt="">
      </li>
      <li @click="onMyShare">
        <img src="../../../static/images/icon_service_7.png" class="icon_tips" alt="">
        <span>我的账单</span>
        <img src="../../../static/images/icon_service_8.png" class="icon_l" alt="">
      </li>
    </ul>
  </div>
</div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters } from 'vuex';
  import { getJoinDaysAndSpareMoney } from '../../api/request';

  export default {
    name: '',
    data() {
      return {
        spareMoney: {},
      };
    },
    computed: {
      ...mapGetters([
        'getUser',
      ]),
    },
    created() {
      this.getJoinDaysAndSpareMoneys();
    },
    methods: {
      isAlert() {
        this.isalert = !this.isalert;
      },
      onHelpInfo() {
        window.location.href = 'http://m.oojunzi.com/oojz/helpInfo/getHelpList';
      },
      onMyCoin() {
        this.$router.push({ path: '/service/chargeMoney' });
      },
      onCustomService() {
        this.$confirm('拨打圈圈客服电话：400 9008 023').then((res) => {
          if (res) {
            window.location.href = 'tel://4009008023';
          }
        }, () => {}).catch((error) => {
          console.log(error);
        });
      },
      onMyCard() {
        this.$router.push({ path: '/member/loginCard' });
      },
      onMyShare() {
        this.$router.push({ path: '/service/myshare' });
      },
      onMyMember() {
        this.$router.push({ path: '/service/mymember' });
      },
      onMyHelp() {
        this.$router.push({ path: '/vehicle/mydetail' });
      },
      async getJoinDaysAndSpareMoneys() {
        const res = await getJoinDaysAndSpareMoney();

        if (res.status * 1 === 1) {
          this.spareMoney = res.data;
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  .my-service {
    position: relative;
    background-color: #fafafa;
  }

  .my-user {
    position: absolute;
    top: 42px;
    left: 0;
    width: 100%;

    .user-img {
      margin: 0 auto;
      padding: 8px;
      box-sizing: border-box;
      border: 1Px solid #FFFFFF;
      background-color: rgba(255,255,255,0.5);
      border-radius: 200px;
      width: 182px;
      height: 182px;

      div {
        box-sizing: border-box;
        border: 2Px solid #FFFFFF;
        border-radius: 200px;
        background-color: #FFF;
        overflow: hidden;

      }
    }
  }

  .user-detail-list {
    flex-direction: row;
    justify-content: space-between;
    margin-bottom: 68px;
    width: 100%;

    li {
      width: 33.3%;
      text-align: center;
      color: #FFF;

      span {
        display: block;
      }

      .top {
        margin-bottom: 16px;
        font-size: 72px;
      }
      .bottom {
        font-size: 20px;
      }

      .name {
        padding-top: 40px;
        font-size: 32px;
      }
    }
  }

  .user-e {
    text-align: center;

    .experience {
      position: relative;
      display: inline-block;
      margin-right: 12px;
      width: 480px;
      height: 26px;
      background-color: rgba(86,86,86, 0.2);
      border-radius: 26px;
      box-shadow: 0px 0px 8px #f8f8f8;
      vertical-align: top;

      span {
        position: absolute;
        top: 0px;
        left: 0px;
        height: 26px;
        background-color: rgba(81,81,81, 1);
        border-radius: 26px;
      }
    }

    .experience-num {
      font-size: 20px;
      line-height: 26px;
      color: rgb(248,248,248);
    }
  }

  .my-list {
    position: relative;
    z-index: 9;
    margin: -45px auto 20px;
    width: 706px;
    height: 200px;
    background-color: #FFF;
    border-radius: 8px;

    .my-list-list {
      flex-direction: row;
      justify-content: space-between;

      li {
        width: 33.3%;
        text-align: center;
        padding-top: 20px;

        img {
          margin: 0 auto 26px;
          width: 84px;
        }

        span {
          font-size: 24px;
          color: rgb(102,102,102);
        }
      }
    }
  }

  .my-nav {
    width: 750px;
    background-color: #FFF;

    ul {
      width: 648px;
      margin: 0 auto;

      li {
        position: relative;
        border-bottom: 1Px solid #f8f8f8;
        padding: 45px 0;

        .icon_tips {
          display: inline-block;
          width: 44px;
          margin-right: 25px;
          vertical-align: top;
        }

        .icon_l {
          position: absolute;
          top: 55px;
          right: 0;
          width: 16px;
        }

        span {
          height: 44px;
          line-height: 44px;
          font-size: 26px;
          color: rgb(51,51,51);
        }

        .my-nav-tips {
          position: absolute;
          top: 45px;
          left: 318px;
          font-size: 22px;
          color: rgb(139,139,139);

          span {
            font-size: 30px;
            color: #fbbf39;
          }
        }
      }
    }
  }
</style>        
