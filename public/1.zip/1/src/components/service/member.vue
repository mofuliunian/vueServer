<template>
<div class="service-member">
  <div class="service-members flex">
    <div class="service-member-left borders">
      <span class="member-num">{{member.memberCnt}}</span>
      <span class="member-text">{{member.isPresident ? '位会员' : '位伙伴'}}</span>
    </div>
    <div class="service-member-right">
      <span class="service-member-text">
        <span class="member-num">{{memberNum}}</span>
        <span class="member-text">{{member.isPresident ? '元' : '圈币'}}</span>
      </span>
      <span class="member-btn" @click="onUpprice" v-if="member.rewardCnt - member.withdrawal > 0 && member.isPresident">{{member.isPresident ? '提现' : '领取'}} ></span>
      <span class="member-up" v-if="member.isPresident">{{member.isPresident ? '已提现' : '已领取'}}：{{member.withdrawal}}{{member.isPresident ? '元' : '圈币'}}</span>
    </div>
  </div>

  <div class="service-member-list" v-for="(item, index) in member.memberList">
    <au-userimg :imgSrc="item.avatar" :className="className"></au-userimg>
    <div class="service-member-detail">
      <h3>{{item.name}}</h3>
      <p>加入时间：{{item.createDate}}</p>
    </div>
    <div class="member-detail-num flex" v-if="member.isPresident">
      <div class="borders">
        邀请人: <span>{{item.inviterName}}</span>
      </div>
      <div>
        贡献邀请: <span>{{item.inviterInviteCnt}}人</span>
      </div>
    </div>
  </div>
</div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters, mapActions } from 'vuex';
  import auUserimg from 'base/userimg/userimg';
  import { getMemberList, getWithdraw, getUncompleted } from '../../api/request';

  export default {
    name: '',
    computed: {
      ...mapGetters([
        'getIsUser',
      ]),
    },
    data() {
      return {
        member: {},
        memberN: 0,
        className: 'service-member-img',
        isHasUncompleted: {},
      };
    },
    components: {
      auUserimg,
    },
    created() {
      this.getHasUncompleted();
      this.getMemberList(1);
    },
    methods: {
      ...mapActions([
        'setRewardCnt',
      ]),
      onUpprice() {
        if (this.member.isPresident) {
          if (this.isHasUncompleted.hasUncompleted === 1) {
            this.$router.push({ path: '/service/upList' });
          } else {
            this.$router.push({ path: '/service/upprice' });
          }
        } else {
          this.getWithdraws();
        }
      },
      async getMemberList(pages) {
        const res = await getMemberList(pages);
        if (res.status * 1 === 1) {
          this.setRewardCnt(res.data.rewardCnt);
          this.member = res.data;
          this.memberNum = this.member.rewardCnt - this.member.withdrawal;
        }
      },
      async getWithdraws() {
        const param = {
          amount: this.member.rewardCnt - this.member.withdrawal,
        };
        const res = await getWithdraw(param);
        if (res.status * 1 === 1) {
          await this.getMemberList(1);
          const self = this;
          this.$alert('领取圈币成功').then(() => {
            self.$router.push({ path: '/service/chargeMoney' });
          });
        } else {
          this.$alert(res.data.message);
        }
      },
      async getHasUncompleted() {
        const res = await getUncompleted();

        if (res.status * 1 === 1) {
          this.isHasUncompleted = res.data;

          if (res.data.hasUncompleted * 1 === 1) {
            this.moneys = res.data.money;
          }
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  .service-member {
    width: 100%;
    height: 100%;
    background-color: #f3f3f3;
  }
  .service-members {
    width: 100%;
    margin-bottom: 20px;
    box-shadow: 0px 0px 8px #f2f2f2;
    flex-direction: row;

    div {
      position: relative;
      width: 50%;
      height: 220px;
      line-height: 220px;
      box-sizing: border-box;
      background-color: #FFF;
    }
    .service-member-left {
      text-align: center;
    }

    .borders {
      border-right: 1Px solid #f3f3f3;
    }

    .member-num {
      font-size: 64px;
      color: rgb(246,187,56);
    }

    .member-text {
      font-size: 28px;
      color: rgb(139,139,139);
    }

    .service-member-text {
      display: inline-block;
      width: 270px;
      text-align: center;
    }

    .member-btn {
      font-size: 26px;
      color: rgb(246,187,56);
    }

    .member-up {
      position: absolute;
      bottom: 10px;
      right: 20px;
      font-size: 22px;
      line-height: 22px;
      color: rgb(139,139,139);
    }
  }

  .service-member-list {
    position: relative;
    background-color: #FFF;

    .service-member-detail {
      position: absolute;
      top: 64px;
      left: 210px;

      h3 {
        margin-bottom: 28px;
        font-size: 34px;
        color: rgb(81,81,81);
      }

      p{
        font-size: 22px;
        color: rgb(81,81,81);
      }
    }
  }

  .member-detail-num {
    margin-bottom: 20px;
    padding: 25px 0;
    border-top: 1Px solid #f3f3f3;
    flex-direction: row;

    div {
      box-sizing: border-box;
      width: 50%;
      height: 60px;
      line-height: 60px;
      text-align: center;
      font-size: 26px;
      color: rgb(139,139,139);

      span {
        color: #515151;
      }
    }

    .borders {
      border-right: 1Px solid #f3f3f3;
    }
  }
</style>        
