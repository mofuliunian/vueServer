<template>
<div class="up-list">
  <div class="up-list-top">
    <div class="up-list-top-cont flex">

      <div class="up-list-state">
        <div class="up-list-state-icon">
          <img src="../../../static/images/icon_updata_1.png" alt="">
        </div>
        <span>提现</span>
      </div>
      
      <span class="dashed dashed-left" :class="{'up-success': (istype >= 1)}"></span>
    
      <div class="up-list-state">
        <div class="up-list-state-icon">
          <img src="../../../static/images/icon_updata_2.png" v-if="istype >= 1" alt="">
          <img src="../../../static/images/icon_updata_3.png" v-else class="icon-error" alt="">
        </div>
        <span :class="{'up-error': !(istype >= 1)}">审核中</span>
      </div>
      <span class="dashed dashed-right" :class="{'up-success': (istype >= 2)}"></span>

      <div class="up-list-state">
        <div class="up-list-state-icon">
          <img src="../../../static/images/icon_updata_4.png" v-if="istype >= 2" alt="">
          <img src="../../../static/images/icon_updata_5.png" v-else class="icon-error" alt="">
        </div>
        <span :class="{'up-error': !(istype >= 2)}">成功</span>
      </div>
    </div>
  </div>

  <div class="up-price" v-if="istype == 0">
    <div class="price-num">
      <span class="price" v-if="istype == 0">{{memberNum}}</span>
      <span>当前可提现金额(元)</span>
    </div>
  </div>

  <div class="up-state" v-if="istype > 0">
    <div>当前提现金额: <span>{{isHasUncompleted.hasUncompleted * 1 == 1 ? moneys : memberNum}}元</span></div>
    <div>状态：
      <span  v-if="istype == 1">提现审核中，通过后三日内到账</span>
      <span  v-if="istype == 2">提现成功，请查收</span>
    </div>
  </div>

  <div class="btns" v-if="istype != 1">
    <div v-if="istype == 0" @click="onUpData">
      <au-button :btnType="btnType" text="发起提现" ></au-button>
    </div>
    <div v-if="istype == 2" @click="onGetmember">
      <au-button :btnType="btnType"  text="继续邀请会员"></au-button>
    </div>

  </div>
  <div class="btn-list flex">
    <div class="borders" @click="isDialogs">设置提现账号</div>
    <div @click="upPriceList">我的提现记录</div>
  </div>

  <div class="up-price-dialog" v-if="isDialog">
    <div class="up-price-dialog-clo" @click="isDialogs"></div>
    <div class="up-price-cont">
      <div class="up-price-conts">
        <div class="title-tel">手机号: {{getUser.mobile}}</div>
        <div class="form">
          <au-input
                  v-model="code.value"
                  class="form-input"
                  :maxLength="code.length"
                  :placeholder="code.placeholder"
                  @handleBlur="onCode">
          </au-input>
          <au-code :codeTel="getUser.mobile" :codeType="2"></au-code>
        </div>
        <div class="alipay" v-if="isAlipay">已有收款账号：{{alipayInfo.alipayAccount}}</div>
        <div class="form">
          <au-input
                  v-model="tel.value"
                  class="form-input"
                  :type="'tel'"
                  :maxLength="tel.length"
                  :placeholder="tel.placeholder"
                  @handleBlur="onTel">
          </au-input>
        </div>
        <div class="form">
          <au-input
                  v-model="name.value"
                  class="form-input"
                  :maxLength="name.length"
                  :placeholder="name.placeholder"
                  @handleBlur="onName">
            <i class="form-icon icon-name"></i>
          </au-input>
        </div>
      </div>
      <div class="up-price-dialog-btn" @click="upDialog">
        确定
      </div>
    </div>
  </div>

</div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters } from 'vuex';
  import auCode from 'base/code/code';
  import { getWithdraw, getAlipayInfo, getUncompleted, getMemberList } from '../../api/request';

  export default {
    name: '',
    data() {
      return {
        istype: 0,
        btnType: 'btn-primary btn-card',
        name: {
          value: '',
          length: 50,
          placeholder: '输入支付宝账号姓名',
          isValue: false,
        },
        tel: {
          value: '',
          length: 50,
          placeholder: '输入支付宝账号',
          isValue: false,
        },
        code: {
          value: '',
          length: 6,
          placeholder: '输入验证码',
          isValue: false,
        },
        isDialog: false,
        isUpdate: false,
        alipayInfo: {
          alipayAccount: '',
          alipayUserName: '',
        },
        moneys: '',
        isHasUncompleted: {},
        isAlipay: false,
        member: {},
        memberNum: 0,
      };
    },
    created() {
      this.getHasUncompleted();
      this.getMemberLists(1);
//      this.getAlipayInfos();
    },
    computed: {
      ...mapGetters([
        'getUser',
        'getRewardCnt',
      ]),
    },
    components: {
      auCode,
    },
    methods: {
      onName(value) {
        if (value !== '') {
          this.name.isValue = true;
        } else {
          this.name.isValue = false;
          this.$tipsAlert('请输入支付宝账号姓名');
        }
        this.isUpdatas();
      },
      onTel(value) {
        if (value !== '') {
          this.tel.isValue = true;
        } else {
          this.tel.isValue = false;
          this.$tipsAlert('输入支付宝账号');
        }
        this.isUpdatas();
      },
      onCode(value) {
        if (value !== '' && value.length === 6) {
          this.code.isValue = true;
        } else {
          this.code.isValue = false;
          this.$Loading('请输入正确的验证码');
        }
        this.isUpdatas();
      },
      isUpdatas() {
        if (this.name.isValue && this.tel.isValue && this.code.isValue) {
          this.isUpdate = true;
        } else {
          this.isUpdate = false;
        }
      },
      isDialogs() {
        this.isDialog = !this.isDialog;
      },
      upDialog() {
        this.isDialogs();
      },
      onGetmember() {
        this.$router.push({ path: '/service/loginCard' });
      },
      upPriceList() {
        this.$router.push({ path: '/service/upList' });
      },
      onUpData() {
//        if (this.isAlipay) {
//          this.getMemberList();
//        } else
        if (this.isUpdate) {
          this.getWithdraws();
        } else {
          this.isDialogs();
        }
      },
      async getWithdraws() {
        const param = {
          alipayAccount: this.tel.value,
          alipayAccountName: this.name.value,
          code: this.code.value,
          amount: this.memberNum,
        };
        const res = await getWithdraw(param);
        if (res.status * 1 === 1) {
          this.istype = 1;
        }
      },
      async getMemberLists(pages) {
        const res = await getMemberList(pages);
        if (res.status * 1 === 1) {
          this.member = res.data;
          this.memberNum = this.member.rewardCnt - this.member.withdrawal;
        }
      },
      async getAlipayInfos() {
        const res = await getAlipayInfo();
        if (res.status * 1 === 1) {
          this.alipayInfo = res.data;
          this.isAlipay = true;
          this.tel.placeholder = '输入新的支付宝账号';
          this.name.placeholder = '输入支付宝账号姓名';
        } else {
          this.isAlipay = false;
        }
      },
      async getHasUncompleted() {
        const res = await getUncompleted();

        if (res.status * 1 === 1) {
          this.isHasUncompleted = res.data;

          if (res.data.hasUncompleted * 1 === 1) {
            this.istype = 1;
            this.moneys = res.data.money;
          }
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  .up-list {
    position: relative;
    width: 100%;
    height: 100%;
  }
  .up-list-top {
    width: 706px;
    margin: 0 auto;
    padding: 90px 0 88px;
    border-bottom: 1Px solid #f8f8f8;
  }

  .up-list-top-cont {
    position: relative;
    width: 626px;
    margin: 0 auto;
    flex-direction: row;
    justify-content: space-between;

    .up-list-state {
      width: 100px;
      text-align: center;
      color: rgb(81,81,81);
    }

    span {
      display: block;
      margin-top: 22px;
    }

    .dashed {
      position: absolute;
      top: 50px;
      width: 134px;
      margin-top: 0;
      border-top: 2Px dashed #8b8b8b;
    }
    .dashed-left {
      left: 115px;
    }

    .dashed-right {
      right: 115px;
    }

    .up-success {
      border-color: #fbbf39;
    }

    .up-error{
      color: rgb(139,139,139);
    }

    .up-list-state-icon {
      position: relative;
      width: 100px;
      height: 100px;

      .icon-error {
        position: absolute;
        top: 0;
        left: 0;
      }
    }
  }

  .up-price {
    padding-top: 146px;

    .price-num {
      text-align: center;

      span {
        display: block;
        font-size: 24px;
        color: rgb(139,139,139);
      }

      .price {
        margin-bottom: 20px;
        font-size: 80px;
        color: rgb(251,191,57);
      }
    }
  }

  .up-state {
    padding-top: 67px;
    padding-left: 62px;
    font-size: 28px;
    color: rgb(81,81,81);

    div {
      margin-bottom: 50px;

      span {
        color: rgb(139,139,139);
      }
    }
  }

  .btns {
    position: absolute;
    width: 100%;
    bottom: 261px;
  }

  .btn-list {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    background-color: #f5f5f5;
    border-top: 1Px solid #d4d4d4;
    flex-direction: row;

    div {
      height: 102px;
      line-height: 102px;
      width: 50%;
      box-sizing: border-box;
      text-align: center;
      font-size: 30px;
      color: rgb(43,43,43);
    }
    .borders {
      border-right: 1Px solid #d4d4d4;
    }
  }

  .up-price-dialog {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    overflow: hidden;
    background-color: rgba(0,0,0,0.4);
  }
  .up-price-cont {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 666px;
    background-color: #FFF;
    border-radius: 8px;
    z-index: 9;
  }
  .up-price-conts {
    width: 554px;
    margin: 0 auto;
  }
  .title-tel {
    padding-top: 75px;
    padding-bottom: 70px;
    text-indent: 18px;
    font-size: 34px;
    color: rgb(81,81,81);
  }

  .form {
    position: relative;
    width: 554px;
    margin: 0 auto 30px;
    background-color: #f8f8f8;
  }

  .up-price-dialog-btn {
    margin-top: 128px;
    height: 100px;
    line-height: 100px;
    font-size: 34px;
    color: #FFF;
    background-color: #515151;
    text-align: center;
    border-radius: 0 0 8px 8px;
  }
  .up-price-dialog-clo {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }
</style>        
