import Vue from 'vue';
import Router from 'vue-router';

Vue.use(Router);

const vehicle = () => import('view/vehicle.vue');

const member = () => import('view/member.vue');

const service = () => import('view/service.vue');

const loginIndex = () => import('components/member/index.vue');

const login = () => import('components/member/login/login.vue');

const loginSuccess = () => import('components/member/login/loginSuccess.vue');

const loginCard = () => import('components/member/login/loginCard.vue');

const loginSelect = () => import('components/member/login/loginSelect.vue');

const loginPay = () => import('components/member/login/loginPay.vue');

const vehAdd = () => import('components/vehicle/index.vue');

const examine = () => import('components/vehicle/examine.vue');

const examineTime = () => import('components/vehicle/examineTime.vue');

const vehicleSuccess = () => import('components/vehicle/success.vue');

const detail = () => import('components/vehicle/detail.vue');

const mydetail = () => import('components/vehicle/mydetail.vue');

const myshare = () => import('components/service/myshare.vue');

const shareDetail = () => import('components/service/shareDetail.vue');

const myshareDetail = () => import('components/service/myshareDetail.vue');

const chargeMoney = () => import('components/service/chargeMoney.vue');

const serviceIndex = () => import('components/service/index.vue');

const myService = () => import('components/service/myservice.vue');

const mymember = () => import('components/service/member.vue');

const upprice = () => import('components/service/upprice.vue');

const upList = () => import('components/service/upList.vue');

const router = new Router({
  routes: [
    { path: '/',
      redirect: '/service/index',
    },
    {
      path: '/service',
      component: service,
      children: [
        {
          path: 'index',
          component: serviceIndex,
        },
        {
          path: 'myService',
          component: myService,
        },
        {
          path: 'mymember',
          component: mymember,
        },
        {
          path: 'upprice',
          component: upprice,
        },
        {
          path: 'upList',
          component: upList,
        },
        {
          path: 'myshare',
          component: myshare,
        },
        {
          path: 'shareDetail',
          component: shareDetail,
        },
        {
          path: 'myshareDetail',
          component: myshareDetail,
        },
        {
          path: 'chargeMoney',
          component: chargeMoney,
        },
      ],
    },
    {
      path: '/vehicle',
      component: vehicle,
      children: [
        {
          path: 'vehAdd',
          component: vehAdd,
        },
        {
          path: 'examine',
          component: examine,
        },
        {
          path: 'examineTime',
          component: examineTime,
        },
        {
          path: 'vehicleSuccess',
          component: vehicleSuccess,
        },
        {
          path: 'detail',
          component: detail,
        },
        {
          path: 'mydetail',
          component: mydetail,
        },
      ],
    },
    {
      path: '/member',
      component: member,
      children: [
        {
          path: 'index',
          component: loginIndex,
        },
        {
          path: 'newLogin',
          component: login,
        },
        {
          path: 'loginSuccess',
          component: loginSuccess,
        },
        {
          path: 'loginCard',
          component: loginCard,
        },
        {
          path: 'loginSelect',
          component: loginSelect,
        },
        {
          path: 'loginPay',
          component: loginPay,
        },
      ],
    },
  ],
  scrollBehavior() {
    document.body.scrollTop = 0;
    return { x: 0, y: 0 };
  },
});
export default router;
