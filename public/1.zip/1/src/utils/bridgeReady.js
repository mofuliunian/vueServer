/**
 * Created by chendeping on 18/1/9.
 */
/* eslint-disable*/
export default {
  methods: {
    onBridgeReady() {
      const self = this;
      WeixinJSBridge.invoke('getBrandWCPayRequest', {
        appId: self.getPaySign.appId,     //公众号名称，由商户传入
        timeStamp: self.getPaySign.timeStamp,         //时间戳，自1970年以来的秒数
        nonceStr: self.getPaySign.nonceStr, //随机串
        package: self.getPaySign.packageValue,
        signType: self.getPaySign.signType,         //微信签名方式：
        paySign: self.getPaySign.paySign, //微信签名
      }, function(res){
        if (res.err_msg == "get_brand_wcpay_request:ok" ) {
          self.brandSuccess();
        }
        // 使用以上方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回    ok，但并不保证它绝对可靠。
      });
    },
    bridgeReady() {
      if (typeof WeixinJSBridge == "undefined") {
        if ( document.addEventListener ) {
          document.addEventListener('WeixinJSBridgeReady', this.onBridgeReady, false);
        } else if (document.attachEvent) {
          document.attachEvent('WeixinJSBridgeReady', this.onBridgeReady);
          document.attachEvent('onWeixinJSBridgeReady', this.onBridgeReady);
        }
      } else {
        this.onBridgeReady();
      }
    },
  },
};


