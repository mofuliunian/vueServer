/**
 * Created by chendeping on 18/1/9.
 */

const textArray = [
  '优雅',
  '理性',
  '华丽',
  '典雅',
  '想象力',
  '贵族',
  '动感',
  '优雅',
  '内敛',
  '疯狂',
  '饱满',
  '新奇',
  '野性',
  '随性',
  '迷失',
  '肆意',
  '不羁',
  '彷徨',
  '爆发',
  '典范',
  '睿智',
  '乐享',
  '信赖',
  '智者',
  '引领',
  '独自站立',
  '责任',
  '尊重',
  '进取',
  '低调',
  '自由',
  '认可',
  '不满足',
  '主义',
  '陪伴',
  '宁静',
  '大千有你',
  '去追风',
  '去朝圣',
  '寻爱',
  '就要顽固',
  '偷心',
  '去夜蒲',
  '我是先锋',
  '喜剧之王',
  '去敲门',
  '要暖心',
  '度人',
  '不速客',
  '拆掉枷锁',
  '唯我',
  '求搭车',
  '去西藏',
  '自驾新疆',
];

const getRandom = (min, max) => {
  const r = Math.random() * (max - min);
  const re = Math.round(r + min);
  const res = Math.max(Math.min(re, max), min);

  return res;
};

const getTextArray = (num) => {
  let nums = 51;
  const text = [];
  const isRandom = {};
  for (let i = 0; i < num; i += 1) {
    const getRandoms = getRandom(0, 50);
    if (!isRandom[getRandoms]) {
      isRandom[getRandoms] = true;
      text.push(textArray[getRandoms]);
    } else {
      text.push(textArray[nums]);
      nums += 1;
    }
  }
};

export default getTextArray;
