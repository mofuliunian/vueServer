/**
 * Created by chendeping on 18/1/7.
 */
import { getWXconfig } from '../api/request';
/* eslint-disable */
export const setWxconfig = async () => {
  const res = await getWXconfig();

  if (res.status * 1 === 1) {
    const jsapi = res.data.jsapiSignature;
    wx.config({
      debug: false,
      appId: jsapi.appId,
      timestamp: jsapi.timestamp,
      nonceStr: jsapi.nonceStr,
      signature: jsapi.signature,
      jsApiList: [
        'openEnterpriseChat',
        'openEnterpriseContact',
        'onMenuShareTimeline',
        'onMenuShareAppMessage',
        'onMenuShareQQ',
        'onMenuShareWeibo',
        'onMenuShareQZone',
        'startRecord',
        'stopRecord',
        'onVoiceRecordEnd',
        'playVoice',
        'pauseVoice',
        'stopVoice',
        'onVoicePlayEnd',
        'uploadVoice',
        'downloadVoice',
        'chooseImage',
        'previewImage',
        'uploadImage',
        'downloadImage',
        'translateVoice',
        'getNetworkType',
        'openLocation',
        'getLocation',
        'hideOptionMenu',
        'showOptionMenu',
        'hideMenuItems',
        'showMenuItems',
        'hideAllNonBaseMenuItem',
        'showAllNonBaseMenuItem',
        'closeWindow',
        'scanQRCode'
      ]
    });
    // alert(location.href.split('#')[0])
    wx.ready(function(){
        const link = 'http://oocar.oojunzi.com/heo/#/service/index';
        menuShare('加入圈圈汽车，驶入一个圈子的生意与生活', link, 'http://oocar.oojunzi.com/heo/dist/static/images/share.png', '给爱车保障，给朋友温度，我们不一样！');

    })
    wx.error(function(res){
      // alert(JSON.stringify(res))
    });
    return jsapi;
  }
};

export const menuShare = (title, link, imgUrl, desc) => {
  wx.onMenuShareTimeline({
    title: title, // 分享标题
    link: link, // 分享链接，该链接域名必须与当前企业的可信域名一致
    imgUrl: imgUrl, // 分享图标
    success: function () {
      // 用户确认分享后执行的回调函数
    },
    cancel: function () {
      // 用户取消分享后执行的回调函数
    }
  });

  wx.onMenuShareAppMessage({
    title: title, // 分享标题
    desc: desc, // 分享描述
    link: link, // 分享链接，该链接域名必须与当前企业的可信域名一致
    imgUrl: imgUrl, // 分享图标
    type: 'link', // 分享类型,music、video或link，不填默认为link
    dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
    success: function () {
      // 用户确认分享后执行的回调函数
    },
    cancel: function () {
      // 用户取消分享后执行的回调函数
    }
  });

  wx.onMenuShareQQ({
    title: title, // 分享标题
    desc: desc, // 分享描述
    link: link, // 分享链接
    imgUrl: imgUrl, // 分享图标
    success: function () {
      // 用户确认分享后执行的回调函数
    },
    cancel: function () {
      // 用户取消分享后执行的回调函数
    }
  });

  wx.onMenuShareWeibo({
    title: title, // 分享标题
    desc: desc, // 分享描述
    link: link, // 分享链接
    imgUrl: imgUrl, // 分享图标
    success: function () {
      // 用户确认分享后执行的回调函数
    },
    cancel: function () {
      // 用户取消分享后执行的回调函数
    }
  });

  wx.onMenuShareQZone({
    title: title, // 分享标题
    desc: desc, // 分享描述
    link: link, // 分享链接
    imgUrl: imgUrl, // 分享图标
    success: function () {
      // 用户确认分享后执行的回调函数
    },
    cancel: function () {
      // 用户取消分享后执行的回调函数
    }
  });
};

