/**
 * Created by chendeping on 17/12/18.
 */
import axios from 'axios';
/* eslint-disable*/
axios.defaults.transformRequest = [function (data) {
  let ret = ''
  for (let it in data) {
    ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&';
  }
  return ret;
}];

axios.interceptors.request.use(config => config, error => Promise.reject(error));

axios.interceptors.response.use(response => response, error => Promise.resolve(error.response));

const checkStatus = (response) => {
  // 如果http状态码正常，则直接返回数据
  console.log(response);
  if (response && (response.status === 200 || response.status === 304 || response.status === 400)) {
    return response;
  }
  // 异常状态下，把错误信息返回去
  return {
    status: -404,
    msg: '网络异常',
  };
};

const checkCode = (res) => {
  console.log(res);
  // 如果code异常(这里已经包括网络错误，服务器错误，后端抛出的错误)，可以弹出一个错误提示，告诉用户
  if (res.status === -404) {
    console.log(res.msg);
  }
  return res;
};

/**
 * 请求统一管理
 * 本地启动 设置代理 /config/index.js文件
 * 设置代理请求地址, 这个只在本机打开有效,如果在手机上打开无效,或者手机自己设置代理
 */
export default {
  post(url, data, opt) {
    return axios(Object.assign({
      method: 'post',
      url,
      data,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    }, opt))
      .then(response => checkStatus(response))
      .then(res => checkCode(res));
  },
  get(url, params, opt) {
    const options = typeof opt === 'undefined' ? params : opt;
    return axios(Object.assign({
      method: 'get',
      url,
      params, // get 请求时带的参数
      timeout: 10000,
    }, options))
      .then(response => checkStatus(response))
      .then(res => checkCode(res));
  },
};
