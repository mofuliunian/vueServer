<template>
  <div class="card-cont">
    <img src="../../../static/images/card_bg.png" alt="">
    <div class="vehicle-content">
      <div class="title">祝福语</div>
      <div class="vehicle-contents">
        <div class="vehicle-content-list flex" v-for="(item, index) in list" :class="{'selse-item': index == indexs}">
          <div class="vehicle-name" @click.self="onSeyItem(item, index)">{{item}}</div>
        </div>
      </div>

      <div class="btns" @click="onItemClick">
        <au-button :btnType="'btn-primary btn-card'" text="确认"></au-button>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    data() {
      return {
        list: [
          '注册幸福，验证快乐，点击平安，登录健康，享受美好，愿朋友2018万事顺利！',
          '不乱于心，不困于情。不畏将来，不念过往。如此，安好。2018，新年快乐。',
          '以你之姓，冠我之名，是最美丽的情话。新年快乐。',
          '和别人谈起你，是我想你的方式。新年快乐。',
          '就算大雨让这座城市倾倒，我会给你怀抱。新年快乐。',
          '人在这个世界上，便预示着承受，承受坎坷、磨难、开心。2018，万事顺利！',
          '人生的含义是奋斗。奋斗的动力是成功。成功的秘诀是改变。2018，成功！',
          '心净，是意识的洗礼；心静，是思想的铸造；心境，是灵魂的成熟。新年快乐。',
          '学会改变生活，学会品味沧桑，方可无悔青春，无憾岁月的消逝。新年快乐。',
          '问候简单，却让人感到一丝甘甜；祝福短暂，却能永远伴你平安。新年快乐。',
          '人之相交，交于情；人之相信，信于诚；人之相处，处于心；2018，万事如意！',
          '生活是陀螺，转起忙碌的日子；惦记是风筝线，牵动远近的情谊。祝新年快乐。',
        ],
        text: '',
        indexs: -1,
      };
    },
    methods: {
      onSeyItem(item, index) {
        this.text = item;
        this.indexs = index;
      },
      onItemClick() {
        this.$emit('upDate', this.text);
      },
    },
  };
</script>

<style lang="scss" scoped>
  @import '~assets/styles/variable';
  .card-cont {
    position: absolute;
    width: 100%;
    bottom: 0;
    z-index: 9;
  }
  .vehicle-content {
    position: absolute;
    top: 0;
    width: 100%;
    left: 0;
  }
  .title {
    padding-top: 42px;
    padding-bottom: 44px;
    font-size: 40px;
    line-height: 40px;
    color: rgb(51,51,51);
    text-align: center;
  }

  .vehicle-contents {
    height: 450px;
    overflow-y: auto;
  }

  .vehicle-content-list {
    background-color: #FFF;
    margin-bottom: 20px;
    height: 88px;
    justify-content: center;
  }
  .vehicle-name {
    width: 680px;
    margin: 0 auto;
    font-size: 26px;
    line-height: 36px;
    color: rgb(81,81,81);
  }
  .selse-item {
    background-color: #e5e5e5;
  }
  .btns {
    padding-top: 40px;
  }

</style>        
