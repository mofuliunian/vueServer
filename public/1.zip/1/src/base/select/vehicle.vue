<template>
<div>
  <div class="vehicle-content" id="j-vehicle-content">
    <div class="vehicle-content-list" v-for="(item, index) in list">
      <div class="title" :id="item.title">{{item.title}}</div>
      <div class="vehicle-name" v-for="(vehicle, i) in item.content" @click.self="onItemClick(vehicle)">{{vehicle.brandName}}</div>
    </div>
    <div class="title-list">
      <span v-for="(item, index) in list" @click="goAnchor('#'+ item.title)">{{item.title}}</span>
    </div>
  </div>
</div>
</template>

<script type=text/ecmascript-6>
  import { carBrands } from '../../api/request';

  export default {
    data() {
      return {
        list: [],
      };
    },
    created() {
      this.getCarBrands();
    },
    methods: {
      onItemClick(vehicle) {
        this.$emit('upDate', vehicle);
      },
      goAnchor(selector) {
        const anchor = this.$el.querySelector(selector);
        const content = this.$el.querySelector('#j-vehicle-content');
        content.scrollTop = anchor.offsetTop;
      },
      async getCarBrands() {
        const res = await carBrands();
        const list = [];
        if (res.status * 1 === 1) {
          const brandList = res.data.brandList;
          if (brandList) {
            Object.keys(brandList).forEach((key) => {
              list.push({
                title: key,
                content: brandList[key],
              });
            });
            this.list = list;
          }
        }
      },
    },
  };
</script>

<style lang=scss>
  @import '~assets/styles/variable';
  .vehicle-content {
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 740px;
    overflow-y: auto;
    z-index: 9;
    background-color: $default-body-background;
  }
  .title {
    line-height: 44px;
    height: 44px;
    font-size: 26px;
    text-indent: 32px;
    color: $index-color-text;
    background-color: $vehicle-title-background;
  }
  .vehicle-name {
    height: 88px;
    line-height: 88px;
    font-size: $default-input-placeholder-font-size;
    text-indent: 50px;
    border-bottom: 1Px solid $vehicle-title-background;
  }
  .title-list {
    position: absolute;
    top: 44px;
    right: 0px;
    min-height: 696px;
    background-color: $default-body-background;
    width: 34px;

    span {
      color: $index-color-text;
      font-size: 22px;
      padding-top: 10px;
      padding-bottom: 10px;
      text-indent: 10px;
      display: block;
    }
  }
</style>        
