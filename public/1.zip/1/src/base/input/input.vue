<template>
  <label class="from-wrap" :class="[className]">
    <input
      ref="input"
      class="input"
      :type="type"
      :value="value"
      :placeholder="placeholder"
      :maxLength="maxLength"
      @blur="handleBlur"
      @input="updateValue($event.target.value)"
    />
    <slot></slot>
  </label>

</template>

<script type="text/ecmascript-6">
  export default {
    props: {
      type: {
        type: String,
        default: 'text',
      },
      placeholder: {
        type: String,
        default: '',
      },
      index: {
        type: Number,
        default: 0,
      },
      value: {},
      maxLength: {
        type: Number,
        default: 50,
      },
      className: {
        type: String,
        default: '',
      },
    },
    data() {
      return {
        currentValue: this.value,
      };
    },
    methods: {
      handleBlur() {
        this.$emit('handleBlur', event.target.value, this.index);
      },
      updateValue(val) {
        this.$emit('input', val);
      },
    },
  };
</script>

<style lang="scss" scoped>
  @import '~assets/styles/variable';
  $default-input-width: 544px;
  $default-input-height: 100px;
  $input-placeholder-padding: 94px;
  $input-placeholder-line-height: 16px;

  .from-wrap {
    display: inline-block;
    position: relative;
    .input {
      box-sizing: border-box;
      border: none;
      width: $default-input-width;
      height: $default-input-height;
      padding: 0 $input-placeholder-padding;
      color: $text-color-black-major;
      font-size: $default-input-placeholder-font-size;
      background-color: $default-input-placeholder-color;

      ::-webkit-input-placeholder,
      :-moz-placeholder,
      ::-moz-placeholder,
      :-ms-input-placeholder {
        font-size: default-input-placeholder-font-size;
        color: $text-color-gray-minor;
        line-height: $input-placeholder-line-height;
      }
    }
  }

  .from-wrap-xxl {
    .input {
      width: 600px;
      padding-left: 110px;
    }
  }

</style>
