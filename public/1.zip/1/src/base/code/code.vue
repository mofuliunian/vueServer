<template>
  <div class="get-code">
    <span class="form-get-code" @click="getCode">
        <i :class="{'form-is-time': !isTime}"></i>
        {{text}}
    </span>
  </div>
</template>

<script type="text/ecmascript-6">
  import { getSendCode } from '../../api/request';

  export default {
    name: '',
    props: {
      codeTel: {
        type: String,
        default: '',
      },
      codeType: {
        type: [String, Number],
        default: '',
      },
    },
    data() {
      return {
        text: '获取验证码',
        isTime: true,
      };
    },
    methods: {
      getCode() {
        const res = /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/;
        if (this.codeTel !== '' && res.test(this.codeTel)) {
          this.getSendCodes();
          const self = this;
          if (self.isTime) {
            self.isTime = !self.isTime;
            let time = 60;
            const timeObj = setInterval(() => {
              time -= 1;
              self.text = `${time}s重新获取`;
              if (time < 0) {
                self.text = '获取验证码';
                self.isTime = !self.isTime;
                clearInterval(timeObj);
              }
            }, 1000);
          }
        } else {
          this.$tipsAlert('请填写手机号');
        }
      },
      async getSendCodes() {
        const param = {
          mobile: this.codeTel,
          type: this.codeType,
        };
        const res = await getSendCode(param);
        if (res.status * 1 === 1) {
          this.$emit('upCode', true);
        } else {
          this.$tipsAlert(res.data.message);
          this.$emit('upCode', false);
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  @import '~assets/styles/variable';
  .form-get-code {
    position: absolute;
    top:0;
    right: 0;
    width: 220px;
    height: 100px;
    line-height: 100px;
    font-size: $default-input-placeholder-font-size;
    color: $default-get-code-color;

  i{
    display: inline-block;
    width: 1PX;
    height: 30px;
    margin-top: 35px;
    margin-right: 36px;
    vertical-align: top;
    background-color: $default-get-code-color;
  }
  .form-is-time {
    margin-right: 18px;
  }
  }
</style>        
