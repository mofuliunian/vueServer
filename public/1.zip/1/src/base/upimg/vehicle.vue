<template>
  <div class="up-img">
    <img :src="url" alt="">
    <div class="up-img-content" @click="onUpImg" v-if="isDriver == -1">
      <img src="../../../static/images/icon_upimg_1.png" class="icon-upimg" alt="">
      <p>请上传行驶证照片</p>
    </div>
    <div class="up-imgs-list" v-if="isDriver != -1">
      <ul v-if="isDriver == 1">
        <li>所有人: <input type="text" v-model="driverInfo.owner" @blur="handleBlur"></li>
        <li>车牌号码: <input type="text" v-model="driverInfo.carPlate" @blur="handleBlur"></li>
        <li>车辆识别代码: <input type="text" v-model="driverInfo.carVin" @blur="handleBlur"></li>
        <li>发动机号: <input type="text" v-model="driverInfo.carBrand" @blur="handleBlur"></li>
        <li>注册日期: <input type="text" v-model="driverInfo.issueDate" @blur="handleBlur"></li>
        <li>发证日期: <input type="text" v-model="driverInfo.driveCreateDate" @blur="handleBlur"></li>
      </ul>

      <div class="error" v-if="isDriver == 0">信息识别失败,请重新拍摄</div>
    </div>
    <img src="../../../static/images/icon_upimg_2.png" @click="onUpImg" v-if="isDriver != -1" class="icon-upimg-l" alt="">
  </div>
</template>

<script type="text/ecmascript-6">
  import Main from './main';
  import { getMediaOcr } from '../../api/request';

  export default {
    mixins: [Main],
    name: '',
    data() {
      return {
        url: '../../../static/images/test_3.jpg',
        driverInfo: {
          owner: '',
          carPlate: '',
          carVin: '',
          carBrand: '',
          issueDate: '',
          driveCreateDate: '',
        },
        isDriver: -1,
      };
    },
    methods: {
      onUpImg() {
        this.getimg();
      },
      handleBlur() {
        const data = {
          imgUrl: this.url,
          driverLicenseInfo: this.driverInfo,
        };
        this.$emit('upDate', data, true);
      },
      async setImg(mediaId) {
        const param = {
          mediaId,
          ocrType: 0,
        };
        const res = await getMediaOcr(param);
        if (res.status * 1 === 1) {
          this.$emit('upDate', res.data, true);
          this.driverInfo = res.data.driverLicenseInfo;
          this.url = res.data.imgUrl;
          this.isDriver = 1;
        } else {
          this.$emit('upDate', {}, false);
          this.isDriver = 0;
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  @import "main.scss";
  .up-img-content{
    background-color: #FFF;
    .icon-upimg {
      margin: 116px auto 48px;
    }
    p {
      font-size: 28px;
      text-align: center;
      color: rgb(68,68,68);
    }
  }

  .up-imgs-list {
    position: absolute;
    top:0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
    border-radius: 8px;
    color: #FFF;
    line-height: 38px;
    font-size: 28px;

    ul {
      padding-top: 31px;
      padding-left: 50px;

      li {
        margin-bottom: 20px;
      }

      input {
        background-color: inherit;
        height: 38px;
        line-height: 28px;
        vertical-align: top;
        color: #FFF;
        font-size: 28px;
        padding: 0;
        border: none;
      }
    }
  }

  .icon-upimg-l {
    position: absolute;
    top: 29px;
    right: 37px;
    width: 52px;
  }
  .error {
    height: 398px;
    line-height: 398px;
    text-align: center;
  }
</style>        
