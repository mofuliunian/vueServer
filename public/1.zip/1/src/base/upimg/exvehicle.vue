<template>
  <div class="up-img">
    <img :src="url" alt="">
    <div class="up-img-content" v-if="codeNum && isUpImg == -1"  @click="onUpimg">
      <img src="../../../static/images/icon_upimg_2.png" class="icon-upimg">
      <p>{{text}}</p>
      <div class="code-num">{{codeNum}}</div>
    </div>
    <dvi class="up-img-content up-img-contents"  @click="onUpimg" v-if="isUpImg != -1">
      <img src="../../../static/images/icon_upimg_2.png" alt="">
      <span :class="{'last': index == 4}">{{text}}</span>
    </dvi>
  </div>
</template>

<script type="text/ecmascript-6">
  import Main from './main';
  import { getMediaDownload } from '../../api/request';

  export default {
    name: '',
    mixins: [Main],
    data() {
      return {
        isUpImg: -1,
        url: '/heo/dist/static/images/test_3.jpg',
      };
    },
    methods: {
      onUpimg() {
        this.getimg();
      },
      async setImg(mediaId) {
        const res = await getMediaDownload(mediaId);

        if (res.status * 1 === 1) {
          this.$emit('upDate', res.data, this.index);
          this.url = res.data.url;
          this.isUpImg = 1;
        } else {
          this.isUpImg = 0;
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  @import "main.scss";
  .up-img-content{
    background-color: rgba(0,0,0,0.5);
    .icon-upimg {
      margin: 144px auto 18px;
    }
    p {
      font-size: 30px;
      text-align: center;
      color: #FFF;
    }
    .code-num {
      position: absolute;
      left: 30px;
      bottom: 24px;
      font-size: 50px;
      color: #FFF;
    }
  }
  .up-img-contents {
    background-color: inherit;
  }
  .up-img-contents img{
    position: absolute;
    top:30px;
    right: 32px;
    width: 52px;
  }

  .up-img-contents span {
    position: absolute;
    bottom:30px;
    right: 32px;
    font-size: 34px;
    color: #FFF;
    width: 69px;
    height: 36px;
    line-height: 36px;
    overflow: hidden;

    &.last {
        width: 102px;
    }
  }
</style>        
