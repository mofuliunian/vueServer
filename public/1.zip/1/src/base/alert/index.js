/**
 * Created by chendeping on 17/3/23.
 */
import Vue from 'vue';
import AlertTips from './alertTips';

let instance;
let currentMsg;
const Modal = Vue.extend(AlertTips);

const marge = (target, options) => {
  const tag = target || {};
  /* eslint-disable */
  for (let prop in options) {
    if (options.hasOwnProperty(prop)) {
      tag[prop] = options[prop];
    }
  }
  return tag;
};

const defaultCallback = (action) => {
  if (currentMsg) {
    const callback = currentMsg.callback;
    if (typeof callback === 'function') {
      callback(action);
    }
    if (currentMsg.resolve) {
      const $type = currentMsg.options.$type;
      if ($type === 'confirm' || $type === 'prompt') {
        if (action === 'confirm') {
          currentMsg.resolve(action);
        } else if (action === 'cancel' && currentMsg.reject) {
          currentMsg.reject(action);
        }
      } else {
        currentMsg.resolve(action);
      }
    }
  }
};

const initInstance = () => {
  instance = new Modal({
    el: document.createElement('div'),
  });
  instance.callback = defaultCallback;
  document.body.appendChild(instance.$el);
};

const showMsg = () => {
  if (!instance) {
    initInstance();
  }
  const options = currentMsg.options;
  /* eslint-disable */
  console.log(options);
  for (let prop in options) {
    if (options.hasOwnProperty(prop)) {
      instance[prop] = options[prop];
      console.log(instance[prop], options[prop], prop);
    }
  }
  console.log(instance)

  if (options.$type === 'tipsAlert') {
    setTimeout(() => {
      instance.value = false;
      currentMsg.resolve(options.action);
    }, 2000);
  }
};

const Message = options => new Promise((resolve, reject) => {
  currentMsg = {
    options,
    resolve,
    reject,
  };
  showMsg();
});

export const Alert = (message, title, options) => {
  const op = {
    title,
    msg: message,
    $type: 'alert',
    cancelShow: false,
    confirmShow: true,
    value: true,
    isloading: false,
  };
  const ops = options || {};
  return Message(marge(op, ops));
};

export const Confirm = (message, title, options) => {
  const op = {
    title,
    msg: message,
    $type: 'confirm',
    value: true,
    cancelShow: true,
    confirmShow: true,
    isloading: false,
  };
  const ops = options || {};
  return Message(marge(op, ops));
};

export const TipsAlert = (message, options) => {
  const op = {
    title: '',
    msg: message,
    $type: 'tipsAlert',
    value: true,
    cancelShow: false,
    confirmShow: false,
    isloading: false,
  };
  console.log(op);
  const ops = options || {};
  return Message(marge(op, ops));
};

export const cancelLoading = () => {
  instance.value = false;
};

export const Loading = (message, options) => {
  const op = {
    title: '',
    msg: message || '载入中',
    $type: 'loading',
    value: true,
    cancelShow: false,
    confirmShow: false,
    isloading: true,
  };
  const ops = options || {};
  currentMsg = {
    options: marge(op, ops),
  };
  showMsg();
  return cancelLoading;
  // return Message(marge(op, ops))
};
