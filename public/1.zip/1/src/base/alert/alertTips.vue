<template>
  <transition name="fadeOpacity">
    <div class="service_layer" v-if="value" :class="{service_loading: isloading}">
      <div class="service_layer_content">
        <h3 class="layer_tili" v-if="title">{{title}}</h3>
        <i class="icon" v-if="isloading"></i>
        <div class="layer_content" v-if="msg">{{msg}}</div>
        <div class="layer_btn"
             :class="{layer_btn_confirm: cancelShow}">
                <span @click="handleAction('cancel')"
                      v-if="cancelShow">{{cancelText}}</span>
                <span @click="handleAction('confirm')"
                      v-if="confirmShow">{{confirmText}}</span>
        </div>
      </div>
    </div>
  </transition>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'alert',
    data() {
      return {
        title: '',
        msg: '',
        value: false,
        confirmText: '确定',
        confirmShow: true,
        cancelText: '取消',
        cancelShow: true,
        callback: null,
        action: '',
        isloading: false,
      };
    },
    methods: {
      handleAction(action) {
        this.action = action;
        this.doCancel();
      },
      doCancel() {
        this.value = false;
        if (this.action) {
          this.callback(this.action);
        }
      },
    },
  };
</script>

<style lang="scss" scoped>
  .service_layer {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.4);
    overflow: hidden;
    z-index: 99;
  }

  .service_loading {
    background: transparent;
  }

  .service_loading .service_layer_content {
    width: 2.4rem;
    height: 2.4rem;
    padding: 0;
    background: rgba(0, 0, 0, 0.4);
  }

  .service_loading .icon {
    display: block;
    margin: 0.5rem auto 0;
    width: 0.82rem;
    height: 0.82rem;
    background-image: url(https://si.geilicdn.com/hz_vteam_000c000001591a1f89aa0a02685e_144_144_unadjust.png);
    background-position: 50%;
    background-repeat: no-repeat;
    background-size: contain;
    -webkit-animation: spin 1s linear infinite;
    animation: spin 1s linear infinite;
  }

  @-webkit-keyframes spin {
    to {
      -webkit-transform: rotate(1turn);
      transform: rotate(1turn)
    }
  }

  @keyframes spin {
    to {
      -webkit-transform: rotate(1turn);
      transform: rotate(1turn)
    }
  }

  .service_loading .service_layer_content .layer_content {
    width: 100%;
    text-align: center;
    margin: 0;
    color: #fff;
    margin-top: 0.25rem;
  }

  .service_loading .layer_btn {
    display: none;
  }

  .service_layer_hg .service_layer_content {
    height: 280px;
    margin-top: -140px;
  }

  .service_layer_content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate3d(-50%, -50%, 0);
    padding-top: 56px;
    width: 76%;
    background: #FFF;
    border-radius: 5px;
    overflow: hidden;
  }

  .layer_tili {
    font-size: 36px;
    text-align: center;
    color: #222222;
    padding: 0 0;
    font-weight: 500;
    height: 50px;
  }

  .layer_content {
    font-size: 28px;
    width: 81%;
    margin: 16px auto 56px;
    line-height: 40px;
    color: #737373;
  }

  .layer_btn {
    /*position: absolute;*/
    /*bottom: 0;*/
    /*left:0;*/
    width: 100%;
    font-size: 32px;
    color: #4384D8;
    text-align: center;

    border-top: 1px solid #DDDDDD;
    line-height: 44px;
  }

  .layer_btn span {
    padding: 22px 0;
    display: inline-block;
  }

  .layer_confirm {
    width: 50%;
    display: inline-block;
    height: 2em;
    vertical-align: top;
    border-right: 1px solid #DDDDDD;
    float: left;
    box-sizing: border-box;
    line-height: 2em;
  }

  .layer_again {
    width: 50%;
    display: inline-block;
    font-size: 0.9em;
    height: 3em;
    vertical-align: top;
    padding: 0.8em 0;
    border-right: 1px solid #DDDDDD;
    float: left;
    box-sizing: border-box;
  }

  .layer_again_line {
    line-height: 1.5em;
  }

  .last_confirm {
    border-right: none;
    /*line-height: 1.5em;*/
  }

  .layer_close {
    position: absolute;
    top: 0.2em;
    right: 0.2em;
    width: 1.1em;
    height: 1.1em;
    background: url(https://img.geilicdn.com/open_1474941858446_367.png) no-repeat center;
    background-size: contain;
    display: none;
  }

  .layer_btn_confirm span {
    width: 50%;
    display: inline-block;
    vertical-align: top;
    border-right: 1px solid #DDDDDD;
    float: left;
    box-sizing: border-box;
  }

  @-webkit-keyframes fadeOutOpacity {
    from {
      opacity: 1;
    }

    to {
      opacity: 0;
    }
  }

  @keyframes fadeOutOpacity {
    from {
      opacity: 1;
    }

    to {
      opacity: 0;
    }
  }

  @-webkit-keyframes fadeInOpacity {
    from {
      opacity: 0;
    }

    to {
      opacity: 1;
    }
  }

  @keyframes fadeInOpacity {
    from {
      opacity: 0;
    }

    to {
      opacity: 1;
    }
  }

  .fadeOpacity-enter-active {
    -webkit-animation-name: fadeInOpacity;
    animation-name: fadeInOpacity;
    -webkit-animation-duration: 0.5s;
    animation-duration: 0.5s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
  }

  .fadeOpacity-leave-active {
    -webkit-animation-name: fadeOutOpacity;
    animation-name: fadeOutOpacity;
    -webkit-animation-duration: 0.5s;
    animation-duration: 0.5s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
  }
</style>
