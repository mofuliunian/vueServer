<template>
  <button type="button" :class="[btnType]" @click="btnClick">{{text}}</button>
</template>

<script type="text/ecmascript-6">
  export default {
    props: {
      btnType: {
        type: String,
        default: '',
      },
      text: {
        type: String,
        default: 'Default',
      },
    },
    methods: {
      btnClick() {
        this.$emit('btnClick');
      },
    },
  };
</script>

<style lang="scss" scoped>
  @import '~assets/styles/variable';

  button {
    width: $default-button-width;
    height: $default-button-height;
    line-height: $default-button-height;
    text-align: center;
    border-radius: 50px;
    font-size: $default-button-font-size;
    border: none;
    margin:  0 auto;
    display: block;
  }

  .btn-primary {
    color: $default-button-color;
    background: $default-button-background;
  }
  .btn-disabled{
   background-color: $disabled-button-background;
   color: $disabled-button-color;
  }

  .btn-index{
    width: 666px;
    color: $default-button-color;
    background: $default-button-background;
  }

  .btn-card{
    width: 706px;
  }

</style>

