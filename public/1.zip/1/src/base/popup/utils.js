/* eslint-disable */
let zIndex = 20161224

export const getZIndex = () => {
  return zIndex++
}
