<template>
  <div>
    <div class="index-member-img-xxl" :class="className" v-if="types && types == 'xxl'">
      <img src="../../../static/images/user_img_xxl.png" alt="">
      <img :src="imgSrc" class="index-member-user" alt="">
    </div>
    <div class="index-member-img" :class="className" v-else>
      <img src="../../../static/images/user_img.png" alt="">
      <img :src="imgSrc" class="index-member-user" alt="">
    </div>
  </div>

</template>

<script type="text/ecmascript-6">
  export default {
    props: {
      imgSrc: {
        type: String,
        default: '',
      },
      types: {
        type: String,
        default: '',
      },
      className: {
        type: String,
        default: '',
      },
    },
  };
</script>

<style lang="scss" scoped>
  @import '~assets/styles/variable';
  .index-member-img-xxl {
    position: relative;
    width: 326px;
    height: 326px;

    .index-member-user {
      position: absolute;
      top: 38px;
      left: 44px;
      width: 240px;
      height: 240px;
      border-radius: 240px;
    }
  }
  .index-member-img {
    position: relative;
    width: 270px;
    height: 269px;

    .index-member-user {
      position: absolute;
      top: 28px;
      left: 40px;
      width: 190px;
      height: 190px;
      border-radius: 110px;
    }
  }

  .service-member-img {
    position: relative;
    width: 216px;
    height: 215px;

    .index-member-user {
      position: absolute;
      top: 24px;
      left: 32px;
      width: 150px;
      height: 150px;
      border-radius: 110px;
    }
  }
</style>        
