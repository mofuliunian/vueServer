<template>
  <div class="index-member">
    <div class="index-member-content">
      <div class="name flex">
        <i></i>
        <span>{{userContent.name}}</span>
        <i></i>
      </div>
      <p>{{userContent.text}}</p>
    </div>
    <img class="index-member-bg" src="../../../static/images/user_bg.png" alt="">
    <div class="index-member-imgs">
      <au-userimg :imgSrc="userContent.img"></au-userimg>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import auUserimg from './userimg';

  export default {
    props: {
      userContent: {
        type: Object,
        default: {},
      },
    },
    components: {
      auUserimg,
    },
  };
</script>

<style lang="scss" scoped>
  @import '~assets/styles/variable';
  .index-member {
    position: relative;
    padding-top: 44px;
    margin: 0 auto 0;

    .index-member-content {
      position: relative;
      z-index:9;
      padding-left: 275px;
      height: 220px;
    }

    .index-member-bg {
      position: absolute;
      top: 19px;
      left: 0px;
      width: 100%;
    }

    p {
      width: 438px;
      font-size: 26px;
      line-height: 36px;
      color: $index-color-text;
      margin-top: 10px;
    }
  }

  .name {
    padding-top: 30px;
    width: 290px;
    flex-direction: row;
    justify-content: center;
    align-items: center;
  i {
    display: inline-block;
    width: 60px;
    height: 1Px;
    background-color: $index-color-text;
  }
  span {
    display: inline-block;
    width: 170px;
    text-align: center;
    font-size: 36px;
  }
  }

  .index-member-imgs {
    position: absolute;
    top: 0;
    left: 0;
  }
</style>        
