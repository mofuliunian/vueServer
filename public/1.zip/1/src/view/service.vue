<template>
  <router-view></router-view>
</template>

<style lang="scss">
  .swiper-service {
    position: absolute;
    bottom: 20px;
    width: 100%;
    text-align: center;

    .swiper-pagination-bullet {
      width: 30px;
      height: 10px;
      border-radius: 0;
      background-color: rgba(255,255,255,0.5);

      &.swiper-pagination-bullet-active {
        background-color: #FFF;
      }
    }
  }

  .index-swiper .swiper-service{
    display: none;
  }
</style>        
