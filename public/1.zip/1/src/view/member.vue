<template>
  <div class="member">
    <router-view></router-view>
  </div>
</template>

<style lang="scss">

</style>        
