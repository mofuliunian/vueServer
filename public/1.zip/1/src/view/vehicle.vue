<template>
    <router-view></router-view>
</template>

<style lang="scss">

</style>        
