<template>
    <router-view></router-view>
</template>

<script type="text/ecmascript-6">
  import { mapActions } from 'vuex';
  import { getMine } from './api/request';

  export default {
    name: 'app',
    created() {
      this.getMineDate();
    },
    methods: {
      ...mapActions([
        'setUsr',
        'setIsUser',
        'setWeixinUser',
      ]),
      async getMineDate() {
        const res = await getMine();
        if (res.status * 1 === 1) {
          this.setUsr(res.data);
          this.setIsUser(true);
        } else if (res.data.code === -1) {
          this.$tipsAlert(res.data.message);
        } else {
          this.setIsUser(false);
          this.setWeixinUser(res.data);
        }
      },
    },
  };
</script>

<style lang="scss">
@import "./assets/styles/reset.css";
  @import "./assets/styles/icons.scss";
#app {
  min-height: 100%;
}
.swiper-pagination-bullet {
  display: inline-block;
  width: 20px;
  height: 20px;
  border-radius: 10px;
  margin-left: 10px;
  margin-right: 10px;
  background-color: rgba(113, 110, 108, 0.5);

&.swiper-pagination-bullet-active {
   background-color: #FFF;
 }
}
</style>
