// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue';
import VueCookie from 'vue-cookie';
import VueAwesomeSwiper from 'vue-awesome-swiper';
import './utils/flexible';
import { setWxconfig } from './utils/weixin';
import App from './App';
import router from './router';
import store from './vuex';
import * as Dialog from './base/alert/index';
import buttons from './base/buttons/buttons';
import input from './base/input/input';

window.wxConfigs = setWxconfig();

Vue.component('au-button', buttons);
Vue.component('au-input', input);
Vue.use(VueAwesomeSwiper);
Vue.use(VueCookie);

Vue.prototype.$alert = Dialog.Alert;
Vue.prototype.$confirm = Dialog.Confirm;
Vue.prototype.$tipsAlert = Dialog.TipsAlert;
Vue.prototype.$Loading = Dialog.Loading;

Vue.config.productionTip = false;
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: { App },
});
