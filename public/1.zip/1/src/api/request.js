/**
 * Created by chendeping on 17/12/18.
 */
import http from '../utils/http';

let host = 'http://oocar.oojunzi.com/heo';

if (process.env.NODE_ENV === 'dev') {
  host = 'http://oocar.oojunzi.com/heo';
  console.log('测试环境');
} else if (process.env.NODE_ENV === 'production') {
  host = 'http://oocar.oojunzi.com/heo';
  console.log('线上环境');
}

console.log(location.href.split('#')[0]);

/**
 * 获取微信信息
 *
 * */
export const getWXconfig = () => {
  const baseUrl = window.location.href.split('#')[0];
  const url = `${host}/wx/getJsapiTicket?url=${encodeURIComponent(baseUrl)}`;
  return http.get(url).then(res => Promise.resolve(res.data));
};

/**
 * 注册填提交
 * @param data {Object} 提交数据
 * {
 *  name: '',
 *  mobile: '',
 *  code: ''
 * }
 *
 * */
export const upSave = (data) => {
  const url = `${host}/reg/save`;
  return http.post(url, data).then(res => Promise.resolve(res.data));
};

/**
 * 加入会员
 * @param data {Object} 提交数据
 * {
 *  carBrandId: '', Integer  汽车品牌ID
 *  priceRange: '', String 价格区间 , 10-30
 * }
 *
 * */
export const getJoin = (data) => {
  const url = `${host}/member/join`;
  return http.post(url, data).then(res => Promise.resolve(res.data));
};

/**
 * 检查手机
 *  @param phone {String} 提交数据
 * */

export const checkPhoneE = (phone) => {
  const url = `${host}/reg/checkPhoneExist?mobile=${encodeURIComponent(phone)}`;
  return http.get(url).then(res => Promise.resolve(res.data));
};

/**
 * 获取字典
 *
 * */
export const carBrands = () => {
  const url = `${host}/car/brands`;
  return http.get(url).then(res => Promise.resolve(res.data));
};

/**
 * 生成福卡
 * @param data {Object} 提交数据
 * {
 *  content: ''
 * }
 *
 * */
export const newCard = (data) => {
  const url = `${host}/invitecard/newCard`;
  return http.post(url, data).then(res => Promise.resolve(res.data));
};

/**
 * 图片识别
 * @param data {Object} 提交数据
 * {
 *  mediaId: '', 微信临时素材ID
 *  ocrType: '' 0:行驶证 1:驾驶证
 * }
 *
 * */
export const getMediaOcr = (data) => {
  const url = `${host}/media/ocr`;
  return http.post(url, data).then(res => Promise.resolve(res.data));
};

/**
 * 图片下载
 * @param data {Object} 提交数据
 * {
 *  mediaId: '', 微信临时素材ID
 * }
 *
 * */
export const getMediaDownload = (mediaId) => {
  const url = `${host}/media/download?mediaId=${encodeURIComponent(mediaId)}`;
  return http.get(url).then(res => Promise.resolve(res.data));
};

/**
 * 查询订单是否 付成功
 * @param data {Object} 提交数据
 * {
 *  transactionId: '', 用户id
 *  outTradeNo: '', 订单id
 *
 *  1. 付失败 2.转 退款 3.未 付 4.已关闭 5.已撤销(刷卡 付) 6. 户 付中 7. 付失败(其他原因,如银 返回失败)
 * }
 * */
export const getQueryOrder = (data) => {
  const url = `${host}/member/queryOrder`;
  return http.post(url, data).then(res => Promise.resolve(res.data));
};


/**
 * 获取会员信息
 * */
export const getMine = () => {
  const url = `${host}/account/mine`;
  return http.get(url).then(res => Promise.resolve(res.data));
};

/**
 * 我的会员
 * @param data {Object} 提交数据
 * {
 *  page: '', 页码
 * }
 * */
export const getMemberList = (page) => {
  const url = `${host}/account/memberList?page=${encodeURIComponent(page)}`;
  return http.get(url).then(res => Promise.resolve(res.data));
};

/**
 * 获取短信验证码
 * @param data {Object} 提交数据
 * {
 *  mobile: '', 手机
 *  type: '', 验证码类型 1:注册 2:绑定 付宝
 * }
 * */
export const getSendCode = (data) => {
  const url = `${host}/sms/sendCode`;
  return http.post(url, data).then(res => Promise.resolve(res.data));
};

/**
 * 获取汽车价格区间
 * */
export const getPrices = () => {
  const url = `${host}/car/prices`;
  return http.get(url).then(res => Promise.resolve(res.data));
};


/**
 * 提现
 * @param data {Object} 提交数据
 * {
 * alipayAccount  付宝账号
 * alipayAccountName  付宝账号姓名
 * code 短信验证码
 * amount 提现 额
 * }
 * code 描述 1.短信验证码错误 2.请正确输  付宝账号信息 3.有未完成的提现 4.提现失败,提现账号保存失败 5.提现失败,提现 额超 过可提现额度. 6.提现失败
 * */
export const getWithdraw = (data) => {
  const url = `${host}/account/withdraw`;
  return http.post(url, data).then(res => Promise.resolve(res.data));
};

/**
 * 注册并添加车辆信息
 * */
export const registUserAndAddCar = (data) => {
  const url = `${host}/oocar/registUserAndAddCar`;
  return http.post(url, data).then(res => Promise.resolve(res.data));
};

/**
 * 验车照片提交
 * */
export const subAuditing = (data) => {
  const url = `${host}/oocar/subAuditing`;
  return http.post(url, data).then(res => Promise.resolve(res.data));
};

/**
 * 获取用户加入总天数和节省总金额
 * */
export const getJoinDaysAndSpareMoney = () => {
  const url = `${host}/oocar/getJoinDaysAndSpareMoney`;
  return http.get(url).then(res => Promise.resolve(res.data));
};

/**
 * 获取分摊账单列表
 * */
export const billList = () => {
  const url = `${host}/oocar/billList`;
  return http.get(url).then(res => Promise.resolve(res.data));
};

/**
 * 获取分摊账单列表
 * */
export const billDetail = (week) => {
  const url = `${host}/oocar/billDetail?weekNum=${encodeURIComponent(week)}`;
  return http.get(url).then(res => Promise.resolve(res.data));
};

/**
 * 支付完成扣除圈币修改账单支付状态
 * */
export const changeBillStatus = (data) => {
  const url = `${host}/oocar/changeBillStatus`;
  return http.post(url, data).then(res => Promise.resolve(res.data));
};

/**
 * 我的互助车辆信息
 * */
export const getCarByUserId = () => {
  const url = `${host}/oocar/getCarByUserId`;
  return http.get(url).then(res => Promise.resolve(res.data));
};

/**
 * 获取圈币余额
 * */
export const getBalance = () => {
  const url = `${host}/oocar/getBalance`;
  return http.get(url).then(res => Promise.resolve(res.data));
};

/**
 * 定时开启互助
 * */
export const setRemindTime = (data) => {
  const url = `${host}/oocar/setRemindTime`;
  return http.post(url, data).then(res => Promise.resolve(res.data));
};

/**
 * 获取互助系统总况
 * */
export const getTotalCars = () => {
  const url = `${host}/oocar/getTotalCars`;
  return http.get(url).then(res => Promise.resolve(res.data));
};

/**
 * 获取互助系统总况
 * */
export const getWithdrawList = (page) => {
  const url = `${host}/account/withdraw/list?page=${encodeURIComponent(page)}`;
  return http.get(url).then(res => Promise.resolve(res.data));
};

// /account/withdraw/alipayInfo

/**
 * 获取支付宝账号信息
 * */
export const getAlipayInfo = () => {
  const url = `${host}/account/withdraw/alipayInfo`;
  return http.get(url).then(res => Promise.resolve(res.data));
};

/**
 * 获取会长提现信息
 * */

export const getUncompleted = () => {
  const url = `${host}/account/withdraw/hasUncompleted`;
  return http.get(url).then(res => Promise.resolve(res.data));
};
