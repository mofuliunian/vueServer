/**
 * Created by chendeping on 18/1/9.
 */
import * as types from './mutation-type';
/* eslint-disable no-param-reassign  */
/* eslint-disable no-shadow */
const state = {
  carPlate: '',
  insurance: 0,
  addCar: {},
};

const getters = {
  getCarPlate(state) {
    return state.carPlate;
  },
  getInsurance(state) {
    return state.insurance;
  },
  getAddCar(state) {
    return state.addCar;
  },
};

const mutations = {
  [types.SET_CAR_PLATE](state, data) {
    state.carPlate = data;
  },
  [types.SET_INSURANCE](state, insurance) {
    state.insurance = insurance;
  },
  [types.SET_ADD_CAR](state, addCar) {
    state.addCar = addCar;
  },
};

const actions = {
  setCarPlate({ commit }, plate) {
    commit(types.SET_CAR_PLATE, plate);
  },
  setInsurance({ commit }, insurance) {
    commit(types.SET_INSURANCE, insurance);
  },
  setAddCar({ commit }, addCar) {
    commit(types.SET_ADD_CAR, addCar);
  },
};

export default {
  state,
  getters,
  mutations,
  actions,
};
