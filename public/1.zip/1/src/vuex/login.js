/**
 * Created by chendeping on 18/1/9.
 */
import * as types from './mutation-type';
/* eslint-disable no-param-reassign  */
/* eslint-disable no-shadow */
const state = {
  login: {
    tel: '',
    name: '',
    price: '',
    vehicle: {},
  },
  paySign: {},
  brandSlogan: {},
  memberCnt: 1,
  outTradeNo: '',
  memberJoin: {},
};

const getters = {
  getLogin(state) {
    return state.login;
  },
  getPaySign(state) {
    return state.paySign;
  },
  getBrandSlogan(state) {
    return state.brandSlogan;
  },
  getMemberCnt(state) {
    return state.memberCnt;
  },
  getMemberJoin(state) {
    return state.memberJoin;
  },
};

const mutations = {
  [types.SET_LOGIN](state, data) {
    state.login = data;
  },
  [types.SET_LOGIN_TEL](state, tel) {
    state.login.tel = tel;
  },
  [types.SET_LOGIN_NAME](state, name) {
    state.login.name = name;
  },
  [types.SET_LOGIN_VEHICLE](state, vehicle) {
    state.login.vehicle = vehicle;
  },
  [types.SET_LOGIN_PRICE](state, price) {
    state.login.price = price;
  },
  [types.SET_PAY_SIGN](state, paySign) {
    state.paySign = paySign;
  },
  [types.SET_BRAND_SLOGAN](state, brandSlogan) {
    state.brandSlogan = brandSlogan;
  },
  [types.SET_MEMBER_CNT](state, memberCnt) {
    state.memberCnt = memberCnt;
  },
  [types.SET_MEMBER_JOIN](state, memberJoin) {
    state.memberJoin = memberJoin;
  },
};

const actions = {
  setLogin({ commit }, data) {
    commit(types.SET_LOGIN, data);
  },
  setLoginName({ commit }, name) {
    commit(types.SET_LOGIN_NAME, name);
  },
  setLoginTel({ commit }, tel) {
    commit(types.SET_LOGIN_TEL, tel);
  },
  setLoginVehicle({ commit }, vehicle) {
    commit(types.SET_LOGIN_VEHICLE, vehicle);
  },
  setLoginPrice({ commit }, price) {
    commit(types.SET_LOGIN_PRICE, price);
  },
  setPaySign({ commit }, paySign) {
    commit(types.SET_PAY_SIGN, paySign);
  },
  setBrandSlogan({ commit }, brandSlogan) {
    commit(types.SET_BRAND_SLOGAN, brandSlogan);
  },
  setMemberCnt({ commit }, memberCnt) {
    commit(types.SET_MEMBER_CNT, memberCnt);
  },
  setMemberJoin({ commit }, memberJoin) {
    commit(types.SET_MEMBER_JOIN, memberJoin);
  },
};

export default {
  state,
  getters,
  mutations,
  actions,
};
