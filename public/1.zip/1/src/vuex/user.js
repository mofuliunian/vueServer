/**
 * Created by chendeping on 17/12/27.
 */
import * as types from './mutation-type';
/* eslint-disable no-param-reassign  */
/* eslint-disable no-shadow */
const state = {
  user: {
    name: '',
    avatar: '',
    memberTitle: '',
    memberDays: '',
    saveMoney: '',
    saveMoneyMax: '',
    memberCnt: '',
    rewardCnt: '',
    rewardType: '',
  },
  weixinUser: {},
  isUser: false,
  rewardCnt: '',
};

const getters = {
  getUser(state) {
    return state.user;
  },
  getWXUser(state) {
    return state.weixinUser;
  },
  getIsUser(state) {
    return state.isUser;
  },
  getRewardCnt(state) {
    return state.rewardCnt;
  },
};

const mutations = {
  [types.SET_USER](state, data) {
    state.user = data;
  },
  [types.SET_USER_NAME](state, name) {
    state.user.name = name;
  },
  [types.SET_WX_USER](state, data) {
    state.weixinUser = data;
  },
  [types.SET_IS_USER](state, data) {
    state.isUser = data;
  },
  [types.SET_REWARDCNT](state, rewardCnt) {
    state.rewardCnt = rewardCnt;
  },
};


const actions = {
  setUsr({ commit }, data) {
    commit(types.SET_USER, data);
  },
  setUsrName({ commit }, name) {
    commit(types.SET_USER_NAME, name);
  },
  setWeixinUser({ commit }, data) {
    commit(types.SET_WX_USER, data);
  },
  setIsUser({ commit }, data) {
    commit(types.SET_IS_USER, data);
  },
  setRewardCnt({ commit }, rewardCnt) {
    commit(types.SET_REWARDCNT, rewardCnt);
  },
};

export default {
  state,
  getters,
  mutations,
  actions,
};
