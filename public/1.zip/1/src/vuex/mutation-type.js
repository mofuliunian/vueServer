/**
 * Created by chendeping on 17/12/27.
 */
/**
 * 用户信息
 */

export const SET_USER = 'SET_USER';
export const SET_USER_NAME = 'SET_USER_NAME';
export const SET_WX_USER = 'SET_WX_USER';
export const SET_IS_USER = 'SET_IS_USER';
export const SET_LOGIN = 'SET_LOGIN';
export const SET_LOGIN_TEL = 'SET_LOGIN_TEL';
export const SET_LOGIN_NAME = 'SET_LOGIN_NAME';
export const SET_LOGIN_VEHICLE = 'SET_LOGIN_VEHICLE';
export const SET_LOGIN_PRICE = 'SET_LOGIN_PRICE';
export const SET_PAY_SIGN = 'SET_PAY_SIGN';
export const SET_BRAND_SLOGAN = 'SET_BRAND_SLOGAN';
export const SET_MEMBER_CNT = 'SET_MEMBER_CNT';
export const SET_REWARDCNT = 'SET_REWARDCNT';
export const SET_CAR_PLATE = 'SET_CAR_PLATE';
export const SET_INSURANCE = 'SET_INSURANCE';
export const SET_MEMBER_JOIN = 'SET_MEMBER_JOIN';
export const SET_ADD_CAR = 'SET_ADD_CAR';
